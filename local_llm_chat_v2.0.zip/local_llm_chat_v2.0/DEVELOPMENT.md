# 開発ドキュメント

Local LLM Chat v2.0 の開発に関する技術情報とガイドライン

## プロジェクト構造

```
local_llm_chat_v2.0/
├── local_llm_chat_v2.0.html   # メインアプリケーション
├── assets/                     # 外部ライブラリ（オフライン対応）
│   ├── marked.min.js           # Markdown レンダリング
│   ├── pdf.min.js              # PDF テキスト抽出
│   └── pdf.worker.min.js       # PDF.js Worker
├── css/                        # スタイルシート（8ファイル）
│   ├── base.css                # ベーススタイル
│   ├── chat.css                # チャットUI
│   ├── settings.css            # 設定パネル
│   ├── preset.css              # プリセットパネル
│   ├── notification.css        # 通知ポップアップ
│   ├── file-list.css           # ファイルリスト
│   ├── file-queue.css          # 送信キュー
│   └── log.css                 # ログパネル
├── js/                         # JavaScript モジュール（17ファイル、リファクタリング済み）
│   ├── constants.js            # 定数定義（LIMITS, TIMING, DISPLAY）
│   ├── types.js                # JSDoc型定義
│   ├── dom.js                  # DOM要素参照（Single Source of Truth）
│   ├── logger.js               # ログ機能（4レベル）
│   ├── utils.js                # ユーティリティ関数
│   ├── markdown.js             # Markdown処理
│   ├── storage.js              # localStorage操作と状態管理
│   ├── panel-manager.js        # パネル管理（開閉処理の統一）← NEW
│   ├── chat-ui.js              # チャットUI（メッセージ表示・アクション）
│   ├── prompt-builder.js       # プロンプト構築
│   ├── api-client.js           # API通信（モデル取得・送信・ストリーミング）
│   ├── attachments.js          # ファイル添付処理
│   ├── file-manager.js         # ファイル管理（保存・取得・削除・UI描画）
│   ├── presets.js              # プリセット管理
│   ├── settings.js             # 設定管理
│   ├── history.js              # 履歴管理（エクスポート・クリア）
│   ├── events.js               # イベント処理とキーボードショートカット
│   └── main.js                 # エントリーポイント
├── MANUAL.md                   # ユーザーマニュアル
├── README.md                   # プロジェクト概要
├── CHANGELOG.md                # 変更履歴
├── DEVELOPMENT.md              # このファイル
└── LICENSE                     # MIT License
```

## アーキテクチャ

### 技術スタック

- **HTML5**: セマンティックマークアップ
- **CSS3**: モジュール化されたスタイルシート（8ファイル）
- **JavaScript (ES6+)**: Vanilla JS（フレームワーク不使用）
- **アーキテクチャパターン**: IIFE（即時実行関数式）によるモジュール分割
- **外部依存**: marked.js, PDF.js（すべてローカル同梱）

### モジュール設計

各モジュールは IIFE パターンを使用し、グローバルスコープ汚染を防止：

```javascript
(function() {
  "use strict";
  window.App = window.App || {};
  // モジュールの実装
})();
```

### リファクタリング（v2.0）

v2.0ではコードのリファクタリングを実施し、以下の改善を行いました：

#### 1. パネル管理の統一化
- **新規モジュール**: `js/panel-manager.js`
- **目的**: パネルの開閉処理を統一し、重複コードを削減
- **機能**:
  - `App.openPanel()` - パネルを開く
  - `App.closePanel()` - パネルを閉じる
  - `App.togglePanel()` - パネルの開閉をトグル
  - `App.setupOverlayClickToClose()` - オーバーレイクリック処理

#### 2. 関数の分割と責任の明確化
- **api-client.js**: `handleSend`と`consumeSSE`を小さな関数に分割
  - `uploadPdfFiles()` - PDFアップロード処理
  - `processTextFiles()` - テキストファイル処理
  - `buildContentArray()` - コンテンツ配列構築
  - `updateSendButtonState()` - UI状態管理
  - `handleApiError()` - APIエラー処理
  - `handleSendError()` - 例外エラー処理
  - `parseSSEEvent()` - SSEイベントパース
  - `processSSEBuffer()` - バッファ処理

#### 3. エラーハンドリングの統一
- エラー処理を専用関数に集約
- エラーメッセージの表示を統一

#### 4. 型定義の改善
- JSDoc型定義を拡充
- 新しい型定義: `FileData`, `ModelData`, `RuntimeState`, `ContentItem`

#### 5. 定数の整理
- `App.TIMING` - タイミング関連定数
  - `SSE_TIMEOUT_CHECK_INTERVAL_MS`: 1000ms
  - `NOTIFICATION_DURATION_MS`: 3000ms
  - `FADE_OUT_DURATION_MS`: 300ms
  - `DRAFT_SAVE_DELAY_MS`: 300ms
- `App.DISPLAY` - 表示関連定数
  - `MAX_ERROR_TEXT_LENGTH`: 200文字
  - `MAX_LOGS`: 1000件

### データフロー

```
User Input → JavaScript Modules → API Request → LLM Server
                ↓                                    ↓
         localStorage ←────────────────────── Streaming Response
                ↓
           UI Update
```

### 主要コンポーネント

#### 1. 設定管理（Settings Management）

**ファイル**: `js/settings.js`, `js/storage.js`

```javascript
// 設定の保存と読み込み
App.loadSettings()  // localStorageから読み込み
App.setSettings()   // localStorageに保存
App.saveSettingsFromUI()  // UIから設定を保存
App.applySettingsToUI()   // 設定をUIに反映
```

**設定項目**:
- baseUrl, apiKey, model
- temperature, maxTokens
- systemPrompt, responseStyle
- userLevel, userProfession, userInterests
- darkMode

#### 2. メッセージ管理（Message Management）

**ファイル**: `js/chat-ui.js`, `js/storage.js`, `js/history.js`

```javascript
// メッセージの追加と表示
App.appendMessage(role, content, opts)

// メッセージアクション
- Copy: クリップボードにコピー
- Delete: 個別削除
- Regenerate: AI応答の再生成（assistantのみ）
```

#### 3. モデル同期（Model Synchronization）

**ファイル**: `js/api-client.js`

```javascript
// /v1/models エンドポイントから自動取得
App.refreshModels(availableModels, modelVisionCapableMap, allModelData)

// 埋め込みモデルの自動フィルタリング
App.EMBEDDING_KEYWORDS = ["embed", "embedding", "bge", "e5-", "gte-", "jina"]

// 画像対応モデルの自動判定
App.isModelVisionCapable(modelId, allModelData)
```

#### 4. 会話構築（Conversation Building）

**ファイル**: `js/prompt-builder.js`

```javascript
App.buildConversation(skipImageMessages)

// システムプロンプト構成
基本プロンプト + 応答スタイル + ユーザープロフィール

// コンテキスト管理
- 直近12メッセージのみをAPIに送信（MAX_HISTORY_FOR_API）
- system, user, assistant の交互パターンを維持
```

#### 5. ストリーミング応答（Streaming Response）

**ファイル**: `js/api-client.js`

```javascript
// Server-Sent Events (SSE) でリアルタイム応答
const res = await fetch(`${base}/chat/completions`, {
  method: "POST",
  body: JSON.stringify({
    model,
    messages: [...buildConversation(), userMessage],
    stream: true,
    temperature,
    max_tokens
  }),
  signal: controller.signal  // AbortController for stopping
});

// ReadableStream で逐次処理
const reader = res.body.getReader();
```

#### 6. Vision API 対応（Vision Support）

**ファイル**: `js/attachments.js`, `js/api-client.js`

```javascript
// 画像のbase64エンコード
App.loadImageAsDataURL(file)

// マルチモーダルメッセージ形式
{
  role: "user",
  content: [
    { type: "text", text: "..." },
    { type: "image_url", image_url: { url: "data:image/..." } }
  ]
}
```

#### 7. ファイル管理（File Management）

**ファイル**: `js/file-manager.js`, `js/storage.js`

```javascript
// ファイルの保存
App.saveUploadedFile(file)

// 送信キュー管理
App.addFileToQueue(fileId)
App.removeFileFromQueue(fileId)
App.getQueuedFiles()

// ファイルリストの表示
App.renderFileList()
App.renderFileQueue()
```

#### 8. ログ機能（Logging）

**ファイル**: `js/logger.js`

```javascript
// ログレベル
App.logDebug(message, data)
App.logInfo(message, data)
App.logWarn(message, data)
App.logError(message, data)

// ログの表示
App.renderLogs()
App.toggleLogPanel()
```

#### 9. プリセット管理（Preset Management）

**ファイル**: `js/presets.js`

```javascript
// プリセットの取得
App.getPreset(key)
App.getPresetLabel(key)

// プリセットの編集
App.savePresetFromEditor()
App.resetPresetToDefault()
App.addNewPreset()
App.deleteSelectedPreset()
```

#### 10. パネル管理（Panel Management）

**ファイル**: `js/panel-manager.js` ← NEW

```javascript
// パネルの開閉
App.openPanel(panel, overlay, closeOtherPanels)
App.closePanel(panel, overlay)
App.togglePanel(panel, overlay, closeOtherPanels)

// オーバーレイクリック処理
App.setupOverlayClickToClose(overlay, panel, panelContainer)
```

**使用箇所**:
- 設定パネル（`js/settings.js`）
- プリセットパネル（`js/presets.js`）
- プリセット編集パネル（`js/presets.js`）
- ファイルリストパネル（`js/events.js`）
- ログパネル（`js/logger.js`）

## データモデル

### Message Object

```javascript
{
  role: "user" | "assistant" | "system",
  content: string,
  imageData?: string  // base64-encoded image (user only)
}
```

### Settings Object

```javascript
{
  baseUrl: string,
  apiKey: string,
  model?: string,
  temperature: number,      // 0.0-2.0
  maxTokens: number,        // 1-8192
  systemPrompt: string,
  responseStyle: "concise" | "standard" | "detailed" | "professional",
  userLevel?: "" | "beginner" | "intermediate" | "advanced" | "expert",
  userProfession?: string,
  userInterests?: string,
  darkMode: boolean
}
```

### File Object (FileData)

```javascript
{
  id: string,
  name: string,
  type: string,
  category: "image" | "document",
  data: string,  // DataURL (image) or Base64 (document)
  size: number,
  uploadedAt: number,
  fileObject?: File  // PDF only
}
```

### Model Data (ModelData)

```javascript
{
  id: string,
  capabilities?: {
    vision?: boolean,        // OpenAI形式
    multimodal?: boolean     // LM Studio形式
  }
}
```

### Runtime State (RuntimeState)

```javascript
{
  abortController: AbortController | null,
  availableModels: Set<string>,
  modelVisionCapableMap: Map<string, boolean>,
  allModelData: Array<ModelData>
}
```

### Content Item (ContentItem)

```javascript
{
  type: "text" | "image_url" | "input_file",
  text?: string,                    // type="text"の場合
  image_url?: { url: string },      // type="image_url"の場合
  file_id?: string                  // type="input_file"の場合
}
```

### Log Entry

```javascript
{
  level: "debug" | "info" | "warn" | "error",
  message: string,
  timestamp: string,
  data?: any
}
```

## localStorage 使用状況

### ストレージキー（v2.0）

```javascript
App.STORAGE_KEYS = {
  HISTORY: "chatHistory_v2.0",
  SETTINGS: "chatSettings_v2.0",
  PRESETS: "chatPresets_v2.0",
  DRAFT: "chatDraft_v2.0",
  PRESET_LABELS: "chatPresetLabels_v2.0",
  MODEL_VISION_CAPABILITIES: "modelVisionCapabilities_v2.0",
  FILES: "chatFiles_v2.0"
}
```

### 定数定義（v2.0）

```javascript
// 制限値
App.LIMITS = {
  IMAGE_MAX_BYTES: 20 * 1024 * 1024,  // 20MB
  FILE_MAX_BYTES: 1 * 1024 * 1024,    // 1MB
  PDF_MAX_BYTES: 5 * 1024 * 1024,     // 5MB
  MAX_HISTORY_FOR_API: 12,
  MAX_TEXTAREA_PX: 240,
  MIN_TEXTAREA_PX: 56,
  REQUEST_TIMEOUT_MS: 30000,
  SSE_TIMEOUT_MS: 60000
}

// タイミング関連定数（リファクタリングで追加）
App.TIMING = {
  SSE_TIMEOUT_CHECK_INTERVAL_MS: 1000,
  NOTIFICATION_DURATION_MS: 3000,
  FADE_OUT_DURATION_MS: 300,
  DRAFT_SAVE_DELAY_MS: 300
}

// 表示関連定数（リファクタリングで追加）
App.DISPLAY = {
  MAX_ERROR_TEXT_LENGTH: 200,
  MAX_LOGS: 1000
}
```

### データサイズ考慮事項

- localStorage の一般的な上限: 5-10MB
- base64画像データはサイズが大きくなる可能性あり
- 直近12メッセージのみをAPIに送信することでコンテキスト長を制限
- ログは最大1000件まで保持（`App.DISPLAY.MAX_LOGS`）

## API 仕様

### エンドポイント

```
GET  /v1/models              # モデル一覧取得
POST /v1/chat/completions    # チャット応答生成（ストリーミング）
POST /v1/files               # ファイルアップロード（PDF用）
```

### リクエスト例

```json
{
  "model": "llama-3.1-swallow-8b-instruct-v0.5",
  "messages": [
    {
      "role": "system",
      "content": "You are a helpful assistant."
    },
    {
      "role": "user",
      "content": "Hello!"
    }
  ],
  "stream": true,
  "temperature": 0.7,
  "max_tokens": 2048
}
```

### レスポンス形式（ストリーミング）

```
data: {"choices":[{"delta":{"content":"Hello"}}]}
data: {"choices":[{"delta":{"content":" there"}}]}
data: [DONE]
```

## セキュリティ考慮事項

1. **ローカル実行**: すべての処理がローカル環境で完結
2. **データ保存**: ブラウザのlocalStorageのみ使用（外部サーバーには送信しない）
3. **API通信**: LLMサーバーへの通信はlocalhostのみ（デフォルト）
4. **XSS対策**: marked.jsによるMarkdown変換（サニタイズ済み）
5. **ファイルサイズ制限**: 画像20MB、テキストファイル1MB、PDF5MB

## パフォーマンス最適化

1. **ストリーミング**: 逐次的に応答を表示（全体の待機時間を短縮）
2. **コンテキスト制限**: 直近12メッセージのみを送信（`MAX_HISTORY_FOR_API`）
3. **イベント委譲**: メッセージアクションボタンにイベント委譲を使用
4. **ファイルサイズ制限**: 画像20MB以下、テキストファイル1MB以下、PDF5MB以下
5. **ログ制限**: 最大1000件まで保持（`App.DISPLAY.MAX_LOGS`、古いログは自動削除）
6. **関数の分割**: 大きな関数を小さな関数に分割し、再利用性と可読性を向上
7. **共通処理の統一**: パネル管理などの共通処理を統一し、コードの重複を削減

## テスト

### 手動テスト項目

#### 基本機能
- [ ] メッセージ送信
- [ ] ストリーミング応答表示
- [ ] 応答の停止
- [ ] 履歴のクリア

#### 設定機能
- [ ] Temperature変更
- [ ] Max Tokens変更
- [ ] System Prompt変更
- [ ] 応答スタイル変更
- [ ] ユーザープロフィール設定
- [ ] 設定のリセット

#### Vision機能
- [ ] 画像ファイル選択
- [ ] 画像ペースト
- [ ] 画像削除
- [ ] 画像付きメッセージ送信

#### ファイル管理機能
- [ ] ファイルのアップロード
- [ ] ファイルリストの表示
- [ ] 送信キューへの追加/削除
- [ ] ファイルの削除
- [ ] PDFファイルの処理

#### ログ機能
- [ ] ログパネルの表示
- [ ] ログレベルの確認
- [ ] ログのクリア

#### プリセット機能
- [ ] プリセットの挿入
- [ ] プリセットの編集
- [ ] プリセットの追加/削除
- [ ] プリセットのリセット

#### UI/UX
- [ ] ダークモード切り替え
- [ ] レスポンシブデザイン
- [ ] キーボードショートカット
- [ ] メッセージアクション（コピー、削除、再生成）

#### データ永続化
- [ ] 設定の自動保存・読み込み
- [ ] 履歴の自動保存・読み込み
- [ ] 履歴のエクスポート
- [ ] ファイルの永続化

## デバッグ

### ブラウザコンソールでの確認

```javascript
// 保存されている設定を確認
JSON.parse(localStorage.getItem("chatSettings_v2.0"))

// 会話履歴を確認
JSON.parse(localStorage.getItem("chatHistory_v2.0"))

// ファイル一覧を確認
JSON.parse(localStorage.getItem("chatFiles_v2.0"))

// ログを確認
App.getLogs()

// 設定をクリア
localStorage.removeItem("chatSettings_v2.0")

// 履歴をクリア
localStorage.removeItem("chatHistory_v2.0")
```

### よくある問題

1. **モデル一覧が取得できない**
   - LLMサーバーが起動しているか確認
   - Base URLが正しいか確認（http://localhost:1234/v1）
   - ログパネルでエラーを確認

2. **応答が返ってこない**
   - ブラウザのコンソールでエラーを確認
   - ログパネルでエラーログを確認
   - LLMサーバーのログを確認
   - モデルが正しくロードされているか確認

3. **画像が送信できない**
   - Vision対応モデルを選択しているか確認
   - 画像サイズが20MB以下か確認
   - ログパネルでデバッグログを確認

4. **ファイルが添付できない**
   - ファイルサイズが制限内か確認（画像20MB、テキスト1MB、PDF5MB）
   - ログパネルでエラーログを確認

## 貢献ガイドライン

### コーディング規約

1. **命名規則**
   - 変数: camelCase
   - 定数: UPPER_SNAKE_CASE
   - 関数: camelCase
   - ファイル名: kebab-case

2. **コメント**
   - JSDocによる型定義を追加（`js/types.js`を参照）
   - 複雑なロジックには説明コメントを追加
   - 関数にはJSDocコメントを記述

3. **フォーマット**
   - インデント: スペース2個
   - セミコロン: 使用する

4. **モジュール設計**
   - IIFEパターンを使用
   - `window.App` オブジェクトに機能を追加
   - グローバルスコープ汚染を避ける

5. **関数設計**
   - 単一責任の原則に従う
   - 大きな関数は小さな関数に分割
   - 再利用可能な処理は共通関数として抽出

6. **定数管理**
   - マジックナンバーは`constants.js`で定数化
   - `App.LIMITS`、`App.TIMING`、`App.DISPLAY`を使用

7. **エラーハンドリング**
   - エラー処理は専用関数に集約
   - エラーメッセージは統一された形式で表示

### 機能追加の流れ

1. 要件定義
2. 実装（モジュール分割を考慮）
   - 既存の共通機能（パネル管理など）を活用
   - 関数は小さな責任単位に分割
   - 定数は`constants.js`に追加
   - JSDoc型定義を`types.js`に追加
3. テスト
4. ドキュメント更新（MANUAL.md, CHANGELOG.md, DEVELOPMENT.md）
5. コミット

### リファクタリングガイドライン

1. **重複コードの削除**
   - 同じ処理が複数箇所にある場合は共通関数として抽出
   - パネル管理は`panel-manager.js`を使用

2. **関数の分割**
   - 100行を超える関数は分割を検討
   - 単一責任の原則に従う

3. **定数の整理**
   - マジックナンバーは`constants.js`に定数として定義
   - タイミング関連は`App.TIMING`、表示関連は`App.DISPLAY`を使用

4. **型定義の追加**
   - 新しいデータ構造は`types.js`にJSDoc型定義を追加
   - 関数のパラメータと戻り値に型注釈を追加

## 今後の開発予定

### 短期
- [ ] 会話履歴のJSONインポート機能
- [ ] メッセージ検索機能
- [ ] カスタムテーマのサポート

### 中期
- [ ] 会話のフォルダ分類
- [ ] 音声入力対応
- [ ] プラグインシステム

### 長期
- [ ] 複数会話の同時管理
- [ ] クラウド同期オプション
- [ ] モバイルアプリ版

## ライセンス

MIT License - 詳細は [LICENSE](LICENSE) を参照

---

開発に関する質問や提案がある場合は、Issueを作成してください。
