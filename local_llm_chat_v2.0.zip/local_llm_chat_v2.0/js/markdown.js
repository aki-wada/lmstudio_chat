/**
 * Markdown設定（marked.js）
 */

(function() {
  "use strict";

  window.App = window.App || {};

  App.setupMarkdown = function() {
    marked.setOptions({ breaks: true, gfm: true });

    // リンクを必ず別タブで開く（rel も付与）
    const renderer = new marked.Renderer();
    const origLink = renderer.link.bind(renderer);
    renderer.link = (href, title, text) =>
      origLink(href, title, text).replace(
        "<a ",
        '<a target="_blank" rel="noopener noreferrer" '
      );

    marked.use({ renderer, mangle: false, headerIds: false });
  };

})();
