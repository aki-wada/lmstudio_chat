/**
 * プリセット管理
 */

(function() {
  "use strict";

  window.App = window.App || {};

  // デフォルトプリセット（変更不可）
  App.DEFAULT_PRESETS = Object.freeze({
    disease: `以下の疾患について、医学的に正確な解説をしてください。

1. 定義・概要（1-2行）
2. 疫学（発症率、好発年齢・性別）
3. 病態生理（発症機序）
4. 症状・臨床所見
5. 診断基準・検査所見
6. 画像所見（特徴的な所見）
7. 鑑別診断（3つ程度）
8. 治療（第一選択、代替療法）
9. 予後

【疾患名】`,
    ddx: `鑑別を5つ挙げ、可能性(高/中/低)と根拠を1行で示してください。
最後に「見逃し厳禁」3つと追加検査3つ。

【主訴】
【年齢・性別】
【症状・所見】`,
    review: `Strengths/Weaknessesを各3つ。加えて「臨床的意義」「再現性」「統計の妥当性」を1行ずつ。
最後にOverall評価(1-5)と主要修正点3つ。

【研究内容】`,
    stats: `以下のデータに対する最適な統計解析手法を提案してください。

【データの種類】
【比較する群】
【目的】`,
    email: `以下の情報をもとに、丁寧で自然な英文メールを作成してください。
トーン: フォーマル/セミフォーマル/カジュアルのいずれかを指定。
出力: 件名(Subject) + 本文。必要なら3つの代替件名も提示。

【相手】
【用件】
【トーン】`,
    pdf: `以下の文章を箇条書きで要約してください。

【文章】`,
  });

  App.DEFAULT_PRESET_LABELS = Object.freeze({
    disease: "🏥 疾患解説",
    ddx: "💊 鑑別診断",
    pdf: "📄 文章要約",
    review: "📝 論文査読",
    stats: "📈 統計解析",
    email: "✉️ 英文メール作成",
  });

  /** @param {string} key */
  App.getPreset = function(key) {
    const customPresets = App.getCustomPresets();
    // カスタムがあれば優先、なければデフォルト
    return (customPresets[key] !== undefined) ? customPresets[key] : App.DEFAULT_PRESETS[key];
  };

  /** @param {string} key */
  App.getPresetLabel = function(key) {
    const customPresetLabels = App.getCustomPresetLabels();
    return customPresetLabels[key] || App.DEFAULT_PRESET_LABELS[key] || key;
  };

  App.getAllPresetKeys = function() {
    const keys = new Set(Object.keys(App.DEFAULT_PRESETS));
    const customPresetLabels = App.getCustomPresetLabels();
    const customPresets = App.getCustomPresets();
    Object.keys(customPresetLabels).forEach(k => keys.add(k));
    Object.keys(customPresets).forEach(k => keys.add(k));
    return Array.from(keys);
  };

  App.renderPresetUI = function() {
    const keys = App.getAllPresetKeys();
    const current = App.el.presetEditSelect.value;

    // Editor select
    App.el.presetEditSelect.innerHTML = "";
    keys.forEach((key) => {
      const opt = document.createElement("option");
      opt.value = key;
      opt.textContent = App.getPresetLabel(key);
      App.el.presetEditSelect.appendChild(opt);
    });

    if (keys.includes(current)) {
      App.el.presetEditSelect.value = current;
    }

    // Preset panel buttons
    App.el.presetList.innerHTML = "";
    keys.forEach((key) => {
      const btn = document.createElement("button");
      btn.classList.add("preset-item");
      btn.dataset.preset = key;
      btn.textContent = App.getPresetLabel(key);
      btn.addEventListener("click", () => {
        App.insertPresetIntoPrompt(key, App.getPresetLabel(key));
      });
      App.el.presetList.appendChild(btn);
    });

    // 設定画面へのボタンを追加
    const settingsBtn = document.createElement("button");
    settingsBtn.classList.add("preset-item", "preset-settings-btn");
    settingsBtn.textContent = "⚙️ プリセット設定";
    settingsBtn.addEventListener("click", () => {
      App.closePresetPanel();
      App.openPresetEditPanel();
    });
    App.el.presetList.appendChild(settingsBtn);
  };

  App.loadPresetToEditor = function() {
    const key = App.el.presetEditSelect.value;
    App.el.presetEditText.value = App.getPreset(key) || "";
    App.el.deletePresetBtn.disabled = Boolean(App.DEFAULT_PRESETS[key]);
  };

  App.savePresetFromEditor = function() {
    const key = App.el.presetEditSelect.value;
    const customPresets = App.getCustomPresets();
    customPresets[key] = App.el.presetEditText.value;
    App.setCustomPresets(customPresets);
    App.persistCustomPresets();
    App.notify("✅ プリセットを保存しました");
  };

  App.resetPresetToDefault = function() {
    if (!confirm("すべてのカスタムプリセットを破棄してデフォルトに戻しますか？")) {
      return;
    }
    
    App.setCustomPresets({});
    App.setCustomPresetLabels({});
    App.persistCustomPresets();
    App.persistCustomPresetLabels();
    App.renderPresetUI();
    App.el.presetEditSelect.value = Object.keys(App.DEFAULT_PRESETS)[0];
    App.loadPresetToEditor();
    App.notify("✅ すべてのプリセットをデフォルトに戻しました");
  };

  App.resetAllPresets = function() {
    if (!confirm("すべてのプリセットをデフォルトに戻しますか？")) return;
    App.setCustomPresets({});
    App.setCustomPresetLabels({});
    App.persistCustomPresets();
    App.persistCustomPresetLabels();
    App.renderPresetUI();
    App.loadPresetToEditor();
    App.notify("✅ すべてのプリセットをリセットしました");
  };

  App.addNewPreset = function() {
    const label = App.el.newPresetName.value.trim();
    if (!label) {
      App.notify("⚠️ プリセット名を入力してください");
      return;
    }

    const key = `custom_${Date.now()}`;
    const customPresetLabels = App.getCustomPresetLabels();
    const customPresets = App.getCustomPresets();
    customPresetLabels[key] = label;
    customPresets[key] = "";
    App.setCustomPresetLabels(customPresetLabels);
    App.setCustomPresets(customPresets);
    App.persistCustomPresetLabels();
    App.persistCustomPresets();
    App.renderPresetUI();
    App.el.presetEditSelect.value = key;
    App.el.presetEditText.value = "";
    App.el.deletePresetBtn.disabled = false;
    App.el.newPresetName.value = "";
    App.notify(`✅ プリセット「${label}」を追加しました`);
  };

  App.deleteSelectedPreset = function() {
    const key = App.el.presetEditSelect.value;
    if (App.DEFAULT_PRESETS[key]) {
      App.notify("⚠️ デフォルトのプリセットは削除できません");
      return;
    }
    if (!confirm("このカスタムプリセットを削除しますか？")) return;
    const customPresets = App.getCustomPresets();
    const customPresetLabels = App.getCustomPresetLabels();
    delete customPresets[key];
    delete customPresetLabels[key];
    App.setCustomPresets(customPresets);
    App.setCustomPresetLabels(customPresetLabels);
    App.persistCustomPresets();
    App.persistCustomPresetLabels();
    App.renderPresetUI();
    App.el.presetEditSelect.value = Object.keys(App.DEFAULT_PRESETS)[0];
    App.loadPresetToEditor();
    App.notify("✅ カスタムプリセットを削除しました");
  };

  App.togglePresetPanel = function() {
    App.togglePanel(
      App.el.presetPanel,
      null,
      [App.el.settingsPanel, App.el.presetEditPanel]
    );
  };

  App.closePresetPanel = function() {
    App.closePanel(App.el.presetPanel, null);
  };

  App.togglePresetEditPanel = function() {
    App.togglePanel(
      App.el.presetEditPanel,
      App.el.presetEditOverlay,
      [App.el.settingsPanel, App.el.presetPanel]
    );
  };

  App.openPresetEditPanel = function() {
    App.openPanel(
      App.el.presetEditPanel,
      App.el.presetEditOverlay,
      [App.el.settingsPanel, App.el.presetPanel]
    );
  };

  App.closePresetEditPanel = function() {
    App.closePanel(App.el.presetEditPanel, App.el.presetEditOverlay);
  };

  /** @param {string} presetKey @param {string} label */
  App.insertPresetIntoPrompt = function(presetKey, label) {
    const presetText = App.getPreset(presetKey);
    if (!presetText) return;

    if (App.el.prompt.value.trim()) App.el.prompt.value = App.el.prompt.value + "\n\n" + presetText;
    else App.el.prompt.value = presetText;

    App.autoResizeTextarea(App.el.prompt);
    App.scheduleDraftSave(
      () => App.el.prompt.value || "",
      App.persistDraft,
      App.clearDraft
    );

    // カーソル末尾
    App.el.prompt.focus();
    App.el.prompt.setSelectionRange(App.el.prompt.value.length, App.el.prompt.value.length);

    App.closePresetPanel();
    App.notify(`✅ プリセット「${label}」を挿入しました`);
  };

})();
