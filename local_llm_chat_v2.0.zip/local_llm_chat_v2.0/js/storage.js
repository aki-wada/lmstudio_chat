/**
 * localStorage操作と状態管理
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /**
   * メッセージ履歴
   * @type {Array<Object>}
   * @property {string} role - "user"|"assistant"|"system"
   * @property {string} content - メッセージ内容
   * @property {string} [imageData] - user添付画像（DataURL）
   */
  let messages = [];

  /**
   * アプリケーション設定
   * @type {Object}
   * @property {string} baseUrl
   * @property {string} apiKey
   * @property {string} [model]
   * @property {number} temperature
   * @property {number} maxTokens
   * @property {string} systemPrompt
   * @property {string} responseStyle - "concise"|"standard"|"detailed"|"professional"
   * @property {string} [userLevel]
   * @property {string} [userProfession]
   * @property {string} [userInterests]
   * @property {boolean} darkMode
   */
  let settings = /** @type {any} */ ({});

  /** @type {Record<string,string>} */
  let customPresets = {};

  /** @type {Record<string,string>} */
  let customPresetLabels = {};

  let draftSaveTimer = null;

  // ---------------------------------------------------------------------------
  // Settings
  // ---------------------------------------------------------------------------

  /**
   * 設定を読み込む
   * @returns {Object} 設定オブジェクト
   */
  App.loadSettings = function() {
    const raw = localStorage.getItem(App.STORAGE_KEYS.SETTINGS) || "{}";
    const s = App.safeJSONParse(raw, {});
    return /** @type {any} */ ({
      baseUrl: s.baseUrl || "http://localhost:1234/v1",
      apiKey: s.apiKey || "lmstudio",
      model: s.model,
      temperature: (typeof s.temperature === "number") ? s.temperature : 0.7,
      maxTokens: (typeof s.maxTokens === "number") ? s.maxTokens : 2048,
      systemPrompt: s.systemPrompt || "You are a helpful Japanese-speaking assistant for a radiologist.",
      responseStyle: s.responseStyle || "standard",
      userLevel: s.userLevel || "",
      userProfession: s.userProfession || "",
      userInterests: s.userInterests || "",
      darkMode: Boolean(s.darkMode),
    });
  };

  App.getSettings = function() {
    return settings;
  };

  App.setSettings = function(newSettings) {
    settings = newSettings;
    localStorage.setItem(App.STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  };

  // ---------------------------------------------------------------------------
  // History
  // ---------------------------------------------------------------------------

  /**
   * 会話履歴を読み込む
   * @returns {Array<Object>} メッセージ配列
   */
  App.loadHistory = function() {
    const raw = localStorage.getItem(App.STORAGE_KEYS.HISTORY) || "[]";
    messages = App.safeJSONParse(raw, []);
    return messages;
  };

  App.getMessages = function() {
    return messages;
  };

  App.addMessage = function(message) {
    messages.push(message);
    App.persistHistory();
  };

  App.removeMessage = function(index) {
    messages.splice(index, 1);
    App.persistHistory();
  };

  App.clearMessages = function() {
    messages = [];
    localStorage.removeItem(App.STORAGE_KEYS.HISTORY);
  };

  App.persistHistory = function() {
    localStorage.setItem(App.STORAGE_KEYS.HISTORY, JSON.stringify(messages));
  };

  // ---------------------------------------------------------------------------
  // Presets
  // ---------------------------------------------------------------------------

  App.loadCustomPresets = function() {
    const raw = localStorage.getItem(App.STORAGE_KEYS.PRESETS) || "{}";
    customPresets = App.safeJSONParse(raw, {});
  };

  App.getCustomPresets = function() {
    return customPresets;
  };

  App.setCustomPresets = function(presets) {
    customPresets = presets;
    App.persistCustomPresets();
  };

  App.persistCustomPresets = function() {
    localStorage.setItem(App.STORAGE_KEYS.PRESETS, JSON.stringify(customPresets));
  };

  App.loadCustomPresetLabels = function() {
    const raw = localStorage.getItem(App.STORAGE_KEYS.PRESET_LABELS) || "{}";
    customPresetLabels = App.safeJSONParse(raw, {});
  };

  App.getCustomPresetLabels = function() {
    return customPresetLabels;
  };

  App.setCustomPresetLabels = function(labels) {
    customPresetLabels = labels;
    App.persistCustomPresetLabels();
  };

  App.persistCustomPresetLabels = function() {
    localStorage.setItem(App.STORAGE_KEYS.PRESET_LABELS, JSON.stringify(customPresetLabels));
  };

  // ---------------------------------------------------------------------------
  // Model Vision Capabilities (実際の送信結果から記録)
  // ---------------------------------------------------------------------------

  /**
   * モデルの画像対応情報を保存（実際の送信結果から記録）
   * @param {string} modelId
   * @param {boolean} isVisionCapable
   */
  App.saveModelVisionCapability = function(modelId, isVisionCapable) {
    if (!modelId) return;
    try {
      const raw = localStorage.getItem(App.STORAGE_KEYS.MODEL_VISION_CAPABILITIES) || "{}";
      const capabilities = JSON.parse(raw);
      capabilities[modelId] = isVisionCapable;
      localStorage.setItem(App.STORAGE_KEYS.MODEL_VISION_CAPABILITIES, JSON.stringify(capabilities));
    } catch (e) {
      App.logError("モデルの画像対応情報の保存に失敗しました", e);
    }
  };

  /**
   * モデルの画像対応情報を読み込み
   * @returns {Record<string, boolean>} モデルID -> 画像対応フラグ
   */
  App.loadModelVisionCapabilities = function() {
    try {
      const raw = localStorage.getItem(App.STORAGE_KEYS.MODEL_VISION_CAPABILITIES) || "{}";
      return JSON.parse(raw);
    } catch (e) {
      App.logError("モデルの画像対応情報の読み込みに失敗しました", e);
      return {};
    }
  };

  // ---------------------------------------------------------------------------
  // Draft
  // ---------------------------------------------------------------------------

  App.loadDraft = function() {
    return localStorage.getItem(App.STORAGE_KEYS.DRAFT) || "";
  };

  App.persistDraft = function(text) {
    localStorage.setItem(App.STORAGE_KEYS.DRAFT, text);
  };

  App.clearDraft = function() {
    localStorage.removeItem(App.STORAGE_KEYS.DRAFT);
  };

  App.scheduleDraftSave = function(getDraftText, persistDraftFn, clearDraftFn) {
    if (draftSaveTimer) clearTimeout(draftSaveTimer);
    const delay = App.TIMING?.DRAFT_SAVE_DELAY_MS || 300;
    draftSaveTimer = setTimeout(() => {
      const text = getDraftText();
      if (text.trim()) persistDraftFn(text);
      else clearDraftFn();
    }, delay);
  };

  // ---------------------------------------------------------------------------
  // Files
  // ---------------------------------------------------------------------------

  /**
   * アップロード済みファイル一覧
   * @type {Array<Object>}
   */
  let files = [];

  /**
   * ファイル一覧を読み込む
   * @returns {Array<Object>} ファイル配列
   */
  App.loadFiles = function() {
    const raw = localStorage.getItem(App.STORAGE_KEYS.FILES) || "[]";
    files = App.safeJSONParse(raw, []);
    return files;
  };

  /**
   * ファイル一覧を取得
   * @returns {Array<Object>} ファイル配列
   */
  App.getFiles = function() {
    return files;
  };

  /**
   * ファイルを保存
   * @param {Object} fileData - ファイルデータ
   * @param {string} fileData.name - ファイル名
   * @param {string} fileData.type - MIMEタイプ
   * @param {string} fileData.category - "image" | "document"
   * @param {string} fileData.data - DataURL（画像）またはBase64（その他）
   * @param {number} fileData.size - ファイルサイズ（バイト）
   * @param {File} [fileData.fileObject] - 元のFileオブジェクト（PDFなど）
   */
  App.saveFile = function(fileData) {
    const file = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: fileData.name,
      type: fileData.type,
      category: fileData.category,
      data: fileData.data,
      size: fileData.size,
      uploadedAt: Date.now(),
      fileObject: fileData.fileObject || null,
    };
    files.push(file);
    App.persistFiles();
    return file;
  };

  /**
   * ファイルを削除
   * @param {string} fileId - ファイルID
   */
  App.deleteFile = function(fileId) {
    const index = files.findIndex(f => f.id === fileId);
    if (index !== -1) {
      files.splice(index, 1);
      App.persistFiles();
    }
  };


  /**
   * ファイル一覧をlocalStorageに保存
   */
  App.persistFiles = function() {
    localStorage.setItem(App.STORAGE_KEYS.FILES, JSON.stringify(files));
  };

})();
