/**
 * チャットUI関連（メッセージ表示、アクション）
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /**
   * 通知メッセージを表示（前方参照用）
   * @param {string} message
   */
  function notifyMessage(message) {
    // ポップアップ通知として表示（チャット画面には表示しない）
    showNotificationPopup(message);
  }

  /**
   * 通知ポップアップを表示
   * @param {string} message - 通知メッセージ
   * @param {number} [duration] - 表示時間（ミリ秒）
   */
  function showNotificationPopup(message, duration) {
    duration = duration || App.TIMING?.NOTIFICATION_DURATION_MS || 3000;
    const container = App.el.notificationContainer;
    if (!container) {
      // フォールバック: コンテナがない場合はチャット画面に表示
      App.appendMessage("system", message, { save: false });
      return;
    }

    // メッセージの種類を判定
    let type = "info";
    if (message.includes("✅") || message.includes("成功") || message.includes("完了")) {
      type = "success";
    } else if (message.includes("⚠️") || message.includes("警告")) {
      type = "warning";
    } else if (message.includes("❌") || message.includes("エラー") || message.includes("失敗")) {
      type = "error";
    }

    // ポップアップ要素を作成
    const popup = document.createElement("div");
    popup.classList.add("notification-popup", type);
    popup.textContent = message;

    // コンテナに追加
    container.appendChild(popup);

    // 自動的に消す
    const timeoutId = setTimeout(() => {
      popup.classList.add("fade-out");
      setTimeout(() => {
        if (popup.parentNode) {
          popup.remove();
        }
      }, App.TIMING?.FADE_OUT_DURATION_MS || 300);
    }, duration);

    // クリックで手動削除も可能
    popup.addEventListener("click", () => {
      clearTimeout(timeoutId);
      popup.classList.add("fade-out");
      setTimeout(() => {
        if (popup.parentNode) {
          popup.remove();
        }
      }, App.TIMING?.FADE_OUT_DURATION_MS || 300);
    });
  }

  /**
   * チャットにメッセージを描画し、必要なら履歴へ保存する
   * @param {"user"|"assistant"|"system"} role - メッセージの役割
   * @param {string} content - メッセージ内容
   * @param {Object} [opts] - オプション
   * @param {boolean} [opts.save=true] - 履歴に保存するか
   */
  App.appendMessage = function(role, content, opts = {}) {
    const { save = true } = opts;

    const container = document.createElement("div");
    container.classList.add("message", role);

    // Copy/Regenerate 用にメッセージ本文を埋め込み
    container.dataset.content = content;

    // 本文（assistantは markdown）
    const body = document.createElement("div");
    body.classList.add("message-content");
    if (role === "assistant") {
      body.innerHTML = marked.parse(content);
    } else {
      body.textContent = content;
    }
    container.appendChild(body);

    // system 以外はアクションボタン表示
    if (role !== "system") {
      container.appendChild(buildMessageActions(container, role));
    }

    App.el.chat.appendChild(container);
    App.scrollToBottom(App.el.chat);

    if (save) {
      App.addMessage({ role, content });
    }
  };

  /**
   * Copy/Delete/Regenerate のUIを作る（systemは呼ばれない）
   * @param {HTMLDivElement} msgDiv
   * @param {"user"|"assistant"|"system"} role - メッセージの役割
   */
  function buildMessageActions(msgDiv, role) {
    const actions = document.createElement("div");
    actions.classList.add("msg-actions");

    const copyBtn = document.createElement("button");
    copyBtn.classList.add("msg-btn");
    copyBtn.textContent = "📋 Copy";
    copyBtn.onclick = async () => {
      await navigator.clipboard.writeText(msgDiv.dataset.content || "");
      notifyMessage("✅ コピーしました");
    };

    const deleteBtn = document.createElement("button");
    deleteBtn.classList.add("msg-btn");
    deleteBtn.textContent = "🗑 Delete";
    deleteBtn.onclick = () => {
      const msgContent = msgDiv.dataset.content || "";
      const messages = App.getMessages();
      const idx = messages.findIndex(m => m.role === role && m.content === msgContent);
      if (idx !== -1) {
        App.removeMessage(idx);
      }
      msgDiv.remove();
      notifyMessage("✅ メッセージを削除しました");
    };

    actions.append(copyBtn, deleteBtn);

    // Regenerate（assistantのみ）
    if (role === "assistant") {
      const regenBtn = document.createElement("button");
      regenBtn.classList.add("msg-btn");
      regenBtn.textContent = "🔄 Regenerate";
      regenBtn.onclick = () => {
        const msgContent = msgDiv.dataset.content || "";
        const messages = App.getMessages();
        const idx = messages.findIndex(m => m.role === "assistant" && m.content === msgContent);
        if (idx !== -1) {
          App.removeMessage(idx);
        }
        msgDiv.remove();
        const messagesAfter = App.getMessages();

        if (messagesAfter.length > 0 && messagesAfter[messagesAfter.length - 1].role === "user") {
          // Regenerate時は最後のuserメッセージの内容を入力欄に設定
          const lastUserMessage = messagesAfter[messagesAfter.length - 1];
          // 表示用テキスト（ファイル名などが含まれる可能性がある）ではなく、元のcontentを使用
          // ただし、contentが配列形式（Vision API形式）の場合は、テキスト部分を抽出
          let userText = "";
          if (typeof lastUserMessage.content === "string") {
            userText = lastUserMessage.content;
          } else if (Array.isArray(lastUserMessage.content)) {
            // Vision API形式の場合、テキスト部分を抽出
            const textPart = lastUserMessage.content.find(item => item.type === "text");
            userText = textPart ? textPart.text : "";
          }
          App.el.prompt.value = userText;
          // テキストエリアのサイズを調整
          App.autoResizeTextarea(App.el.prompt);
          App.el.sendBtn.click();
        } else {
          notifyMessage("⚠️ 再生成するユーザーメッセージがありません");
        }
      };
      actions.appendChild(regenBtn);
    }

    return actions;
  }

  /**
   * 通知メッセージを表示
   * @param {string} message
   */
  App.notify = function(message) {
    notifyMessage(message);
  };

})();

