/**
 * システムプロンプト構築
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /** 応答スタイルの追加指示 */
  function getResponseStyleInstruction() {
    const style = App.el.responseStyle.value || "standard";
    const map = {
      concise: "\n\n【応答スタイル】簡潔に要点のみを述べてください。冗長な説明は避け、核心的な情報のみを提供してください。",
      standard: "",
      detailed: "\n\n【応答スタイル】詳細な説明を心がけてください。背景情報、理由、具体例などを含めて丁寧に説明してください。",
      professional: "\n\n【応答スタイル】専門的で技術的な詳細を重視してください。学術的な正確性を保ち、専門用語を適切に使用し、エビデンスや根拠を明示してください。",
    };
    return map[style] || "";
  }

  /** ユーザープロフィール（任意） */
  function getUserProfileInstruction() {
    const level = App.el.userLevel.value;
    const profession = App.el.userProfession.value.trim();
    const interests = App.el.userInterests.value.trim();
    if (!level && !profession && !interests) return "";

    let out = "\n\n【ユーザー情報】";

    const levelMap = {
      beginner: "ユーザーは初心者です。専門用語を避け、基礎から丁寧に説明してください。",
      intermediate: "ユーザーは中級者です。基本的な知識は持っているものとして、適度な専門用語を使用して説明してください。",
      advanced: "ユーザーは上級者です。専門的な内容を深く掘り下げて説明してください。",
      expert: "ユーザーは専門家です。高度な専門知識を前提とし、最新の研究や詳細な技術的議論を含めてください。",
    };

    if (level && levelMap[level]) out += `\n- ${levelMap[level]}`;
    if (profession) out += `\n- 職業/専門分野: ${profession}`;
    if (interests) out += `\n- 興味・関心: ${interests}`;

    return out;
  }

  /**
   * API送信用の messages を作る（system先頭、交互、末尾assistantは除外）
   * 画像添付は Vision API形式（content配列）に変換。
   *
   * NOTE: system が slice で落ちないように、必ず system + 最後のN-1件に整形する。
   * @returns {Array<{role:string, content:any}>}
   */
  /**
   * API送信用の messages を作る（system先頭、交互、末尾assistantは除外）
   * 画像添付は Vision API形式（content配列）に変換。
   * 
   * @param {boolean} skipImageMessages - trueの場合、画像付きメッセージをスキップ（再送信時用）
   * @returns {Array<{role:string, content:any}>}
   */
  App.buildConversation = function(skipImageMessages = false) {
    const settings = App.getSettings();
    const baseSysPrompt = App.el.systemPrompt.value || settings.systemPrompt;
    const sysPrompt = baseSysPrompt + getResponseStyleInstruction() + getUserProfileInstruction();

    /** @type {Array<{role:string, content:any}>} */
    const conv = [{ role: "system", content: sysPrompt }];

    // 履歴を再読み込みして最新の状態を取得
    App.loadHistory();
    const messages = App.getMessages();
    
    const imageMessages = messages.filter(m => m.role === "user" && m.imageData);
    if (imageMessages.length > 0) {
      App.logWarn(`[buildConversation] 警告: 履歴に画像付きメッセージが${imageMessages.length}件残っています。`, imageMessages);
      if (skipImageMessages) {
        App.logDebug(`[buildConversation] 再送信モードのため、これらをスキップします。`);
      }
    }
    
    let last = "system";
    for (const m of messages) {
      if (!["user", "assistant"].includes(m.role)) continue;
      if (m.role === last) continue;

      // 再送信時（skipImageMessages=true）は画像付きメッセージをスキップ
      if (skipImageMessages && m.role === "user" && m.imageData) {
        App.logWarn(`[buildConversation] 再送信モード: 画像付きメッセージをスキップします。`, m);
        continue;
      }

      // Vision API形式に変換（user画像のみ）
      if (m.role === "user" && m.imageData) {
        const contentArray = [];
        if (m.content) contentArray.push({ type: "text", text: m.content });
        contentArray.push({ type: "image_url", image_url: { url: m.imageData } });
        conv.push({ role: "user", content: contentArray });
      } else {
        conv.push({ role: m.role, content: m.content });
      }

      last = m.role;
    }

    // 末尾がassistantなら削って「次のassistant生成」に備える
    if (conv.length > 1 && conv.at(-1).role === "assistant") conv.pop();

    // systemは常に残し、残りを末尾から LIMITS.MAX_HISTORY_FOR_API-1 個取る
    const tail = conv.slice(1).slice(-(App.LIMITS.MAX_HISTORY_FOR_API - 1));
    return [conv[0], ...tail];
  };

})();
