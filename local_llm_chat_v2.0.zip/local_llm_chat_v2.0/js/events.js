/**
 * イベント配線とキーボードショートカット
 */

(function() {
  "use strict";

  window.App = window.App || {};

  App.setupKeyboardShortcuts = function(handleSend, handleClear) {
    // Enter送信：IME変換中は送信しない
    App.el.prompt.addEventListener("keydown", (e) => {
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    });

    document.addEventListener("keydown", (e) => {
      // Ctrl+K / Cmd+K でクリア
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        handleClear();
      }
      // Esc で設定パネルを閉じる
      if (e.key === "Escape" && App.el.settingsPanel.classList.contains("open")) {
        App.closeSettingsPanel();
      }
      if (e.key === "Escape" && App.el.presetPanel.classList.contains("open")) {
        App.closePresetPanel();
      }
      if (e.key === "Escape" && App.el.presetEditPanel && App.el.presetEditPanel.classList.contains("open")) {
        App.closePresetEditPanel();
      }
      if (e.key === "Escape" && App.el.logPanel && App.el.logPanel.classList.contains("open")) {
        App.closeLogPanel();
      }
    });
  };

  App.setupPasteImage = function() {
    // ペースト機能は新しいファイル管理機能で実装予定
  };

  App.setupDragAndDropImage = function() {
    // ドラッグ&ドロップ機能は新しいファイル管理機能で実装予定
  };

  App.wireSettingsEvents = function(notifyFn) {
    const save = App.saveSettingsFromUI;

    App.el.baseUrl.onchange = save;
    App.el.apiKey.onchange = save;

    App.el.temperature.oninput = () => {
      App.el.tempValue.textContent = App.el.temperature.value;
      save();
    };

    App.el.maxTokens.onchange = save;
    App.el.systemPrompt.onchange = save;
    App.el.responseStyle.onchange = save;
    App.el.userLevel.onchange = save;
    App.el.userProfession.onchange = save;
    App.el.userInterests.onchange = save;

    App.el.darkModeToggle.onclick = () => App.toggleDarkMode();

    App.el.modelSelect.addEventListener("change", (e) => {
      save();
      const id = /** @type {HTMLSelectElement} */ (e.target).value;
      notifyFn(`🔄 モデルを ${id} に切り替えました`);
    });
  };

  App.wireTextareaResize = function() {
    App.el.prompt.addEventListener("input", () => {
      App.autoResizeTextarea(App.el.prompt);
      App.scheduleDraftSave(
        () => App.el.prompt.value || "",
        App.persistDraft,
        App.clearDraft
      );
    });
  };

  App.wireAttachmentEvents = function(handleFileUpload) {
    if (App.el.fileUploadInput) {
      App.el.fileUploadInput.addEventListener("change", (e) => {
        const files = e.target.files;
        if (files && files.length > 0) {
          handleFileUpload(files);
        }
      });
    }
  };

  App.wirePresetEvents = function(
    loadPresetToEditor,
    savePresetFromEditor,
    resetPresetToDefault,
    deleteSelectedPreset,
    resetAllPresets,
    addNewPreset,
    togglePresetPanel,
    closePresetPanel,
    togglePresetEditPanel,
    closePresetEditPanel
  ) {
    // Editor
    App.el.presetEditSelect.onchange = loadPresetToEditor;
    App.el.savePresetBtn.onclick = savePresetFromEditor;
    App.el.resetPresetBtn.onclick = resetPresetToDefault;
    App.el.deletePresetBtn.onclick = deleteSelectedPreset;
    if (App.el.resetAllPresetsBtn) {
      App.el.resetAllPresetsBtn.onclick = resetAllPresets;
    }
    App.el.addPresetBtn.onclick = addNewPreset;

    // Panel open/close
    App.el.presetBtn.onclick = togglePresetPanel;
    App.el.closePresetBtn.onclick = closePresetPanel;
    if (App.el.closePresetEditBtn) {
      App.el.closePresetEditBtn.onclick = closePresetEditPanel;
    }

    // Panel外クリックで閉じる
    document.addEventListener("click", (e) => {
      if (!App.el.presetPanel.classList.contains("open")) return;
      if (App.el.presetPanel.contains(/** @type {any} */ (e.target))) return;
      if (e.target === App.el.presetBtn) return;
      closePresetPanel();
    });

    // プリセット編集パネルのオーバーレイクリックで閉じる
    App.setupOverlayClickToClose(
      App.el.presetEditOverlay,
      App.el.presetEditPanel,
      App.el.presetEditPanel
    );
  };

  /**
   * ファイルリストパネルのイベントを設定
   */
  App.wireFileListEvents = function() {
    // ファイルリストパネルの開閉
    App.openFileListPanel = function() {
      App.openPanel(App.el.fileListPanel, App.el.fileListOverlay);
    };

    App.closeFileListPanel = function() {
      App.closePanel(App.el.fileListPanel, App.el.fileListOverlay);
    };

    App.toggleFileListPanel = function() {
      App.togglePanel(App.el.fileListPanel, App.el.fileListOverlay);
    };

    // 閉じるボタン
    if (App.el.closeFileListBtn) {
      App.el.closeFileListBtn.onclick = App.closeFileListPanel;
    }

    // オーバーレイクリックでファイルリストパネルを閉じる
    App.setupOverlayClickToClose(
      App.el.fileListOverlay,
      App.el.fileListPanel,
      App.el.fileListPanel
    );

    // キューのクリアボタン
    if (App.el.clearQueueBtn) {
      App.el.clearQueueBtn.onclick = () => {
        if (App.getQueuedFiles && App.getQueuedFiles().length > 0) {
          if (confirm("キュー内のすべてのファイルを削除しますか？")) {
            App.clearFileQueue();
            App.renderFileList();
            App.notify("✅ キューをクリアしました");
          }
        }
      };
    }
  };

  /**
   * ログパネルのイベントを設定
   */
  App.wireLogEvents = function() {
    // ログボタン
    if (App.el.logBtn) {
      App.el.logBtn.onclick = () => {
        App.toggleLogPanel();
      };
    }

    // 閉じるボタン
    if (App.el.closeLogBtn) {
      App.el.closeLogBtn.onclick = () => {
        App.closeLogPanel();
      };
    }

    // クリアボタン
    if (App.el.clearLogBtn) {
      App.el.clearLogBtn.onclick = () => {
        if (confirm("すべてのログを削除しますか？")) {
          App.clearLogs();
          App.notify("✅ ログをクリアしました");
        }
      };
    }

    // オーバーレイクリックでログパネルを閉じる
    App.setupOverlayClickToClose(
      App.el.logOverlay,
      App.el.logPanel,
      App.el.logPanel
    );
  };

})();
