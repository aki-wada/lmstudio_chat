/**
 * 設定パネル操作
 */

(function() {
  "use strict";

  window.App = window.App || {};

  App.toggleSettingsPanel = function() {
    App.togglePanel(
      App.el.settingsPanel,
      App.el.settingsOverlay,
      [App.el.presetPanel, App.el.presetEditPanel]
    );
  };

  App.openSettingsPanel = function() {
    App.openPanel(
      App.el.settingsPanel,
      App.el.settingsOverlay,
      [App.el.presetPanel, App.el.presetEditPanel]
    );
  };

  App.closeSettingsPanel = function() {
    App.closePanel(App.el.settingsPanel, App.el.settingsOverlay);
  };

  // オーバーレイクリックで設定画面を閉じる
  App.setupOverlayClickToClose(
    App.el.settingsOverlay,
    App.el.settingsPanel,
    App.el.settingsPanel
  );

  App.toggleDarkMode = function() {
    const isDarkMode = document.body.classList.contains("dark-mode");
    if (isDarkMode) {
      document.body.classList.remove("dark-mode");
    } else {
      document.body.classList.add("dark-mode");
    }
    App.updateDarkModeButton();
    App.saveSettingsFromUI();
  };

  App.updateDarkModeButton = function() {
    const isDarkMode = document.body.classList.contains("dark-mode");
    if (App.el.darkModeToggle) {
      App.el.darkModeToggle.textContent = isDarkMode ? "☀️" : "🌙";
      App.el.darkModeToggle.classList.toggle("active", isDarkMode);
    }
  };

  /** Settings → UIへ反映 */
  App.applySettingsToUI = function() {
    const settings = App.getSettings();
    App.el.baseUrl.value = settings.baseUrl;
    App.el.apiKey.value = settings.apiKey;
    App.el.temperature.value = String(settings.temperature);
    App.el.tempValue.textContent = String(settings.temperature);
    App.el.maxTokens.value = String(settings.maxTokens);
    App.el.systemPrompt.value = settings.systemPrompt;
    App.el.responseStyle.value = settings.responseStyle;
    App.el.userLevel.value = settings.userLevel || "";
    App.el.userProfession.value = settings.userProfession || "";
    App.el.userInterests.value = settings.userInterests || "";

    if (settings.darkMode) {
      document.body.classList.add("dark-mode");
    } else {
      document.body.classList.remove("dark-mode");
    }
    App.updateDarkModeButton();
  };

  /** UI → settingsへ反映し保存 */
  App.saveSettingsFromUI = function() {
    const settings = {
      baseUrl: App.el.baseUrl.value.trim(),
      apiKey: App.el.apiKey.value.trim(),
      model: App.el.modelSelect.value,
      temperature: parseFloat(App.el.temperature.value),
      maxTokens: parseInt(App.el.maxTokens.value, 10),
      systemPrompt: App.el.systemPrompt.value,
      responseStyle: /** @type {any} */ (App.el.responseStyle.value),
      userLevel: App.el.userLevel.value,
      userProfession: App.el.userProfession.value.trim(),
      userInterests: App.el.userInterests.value.trim(),
      darkMode: document.body.classList.contains("dark-mode"),
    };
    App.setSettings(settings);
  };

  /**
   * 設定をデフォルトに戻す
   */
  App.resetSettingsToDefault = function() {
    if (!confirm("設定をデフォルトに戻しますか？")) {
      return;
    }
    const defaultSettings = App.loadSettings();
    // loadSettings()は既存の設定を読み込むので、デフォルト値を直接設定
    const resetSettings = {
      baseUrl: "http://localhost:1234/v1",
      apiKey: "lmstudio",
      model: undefined,
      temperature: 0.7,
      maxTokens: 2048,
      systemPrompt: "You are a helpful Japanese-speaking assistant for a radiologist.",
      responseStyle: "standard",
      userLevel: "",
      userProfession: "",
      userInterests: "",
      darkMode: false,
    };
    App.setSettings(resetSettings);
    App.applySettingsToUI();
    if (App.notify) {
      App.notify("✅ 設定をデフォルトに戻しました");
    }
  };

  /**
   * すべての保存データを消す
   */
  App.clearAllData = function() {
    if (!confirm("⚠️ 警告: すべての保存データ（設定、会話履歴、プリセット、ファイルなど）を削除します。\n\nこの操作は取り消せません。本当に実行しますか？")) {
      return;
    }
    if (!confirm("最後の確認: すべてのデータを削除してもよろしいですか？")) {
      return;
    }
    // すべてのストレージキーを削除
    Object.values(App.STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
    // メモリ上の状態もリセット
    App.clearMessages();
    App.setCustomPresets({});
    App.setCustomPresetLabels({});
    // 設定をデフォルトに戻す（確認ダイアログなし）
    const resetSettings = {
      baseUrl: "http://localhost:1234/v1",
      apiKey: "lmstudio",
      model: undefined,
      temperature: 0.7,
      maxTokens: 2048,
      systemPrompt: "You are a helpful Japanese-speaking assistant for a radiologist.",
      responseStyle: "standard",
      userLevel: "",
      userProfession: "",
      userInterests: "",
      darkMode: false,
    };
    App.setSettings(resetSettings);
    // UIを更新
    App.applySettingsToUI();
    // チャット履歴をクリア
    if (App.el.chat) {
      App.el.chat.innerHTML = "";
    }
    // ファイルリストを更新（空の状態で再読み込み）
    if (App.loadFiles && App.renderFileList) {
      App.loadFiles();
      App.renderFileList();
    }
    // プリセットUIを更新
    if (App.renderPresetUI) {
      App.renderPresetUI();
    }
    if (App.notify) {
      App.notify("✅ すべての保存データを削除しました");
    }
  };

})();
