/**
 * ロガー機能
 * debug, info, warn, errorの4つのレベルとタイムスタンプを提供
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /**
   * ログエントリ
   * @typedef {Object} LogEntry
   * @property {string} level - ログレベル (debug, info, warn, error)
   * @property {string} message - ログメッセージ
   * @property {string} timestamp - タイムスタンプ
   * @property {*} data - 追加データ（オプション）
   */

  /**
   * ログエントリの配列
   * @type {Array<LogEntry>}
   */
  const logs = [];

  /**
   * 最大保持ログ数
   * @type {number}
   */
  const MAX_LOGS = App.DISPLAY?.MAX_LOGS || 1000;

  /**
   * タイムスタンプをフォーマット
   * @returns {string} フォーマットされたタイムスタンプ
   */
  function formatTimestamp() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    return `${hours}:${minutes}:${seconds}.${milliseconds}`;
  }

  /**
   * ログを追加
   * @param {string} level - ログレベル
   * @param {string} message - ログメッセージ
   * @param {*} data - 追加データ（オプション）
   */
  function addLog(level, message, data) {
    const entry = {
      level: level,
      message: message,
      timestamp: formatTimestamp(),
      data: data
    };

    logs.push(entry);

    // 最大保持数を超えた場合、古いログを削除
    if (logs.length > MAX_LOGS) {
      logs.shift();
    }

    // errorレベルのログはconsole.errorに流す
    if (level === 'error') {
      if (data !== undefined) {
        console.error(`[${entry.timestamp}] ${message}`, data);
      } else {
        console.error(`[${entry.timestamp}] ${message}`);
      }
    }
    // warnレベルのログはconsole.warnに流す
    if (level === 'warn') {
      if (data !== undefined) {
        console.warn(`[${entry.timestamp}] ${message}`, data);
      } else {
        console.warn(`[${entry.timestamp}] ${message}`);
      }
    }

    // UIを更新
    if (App.renderLogs) {
      App.renderLogs();
    }
  }

  /**
   * デバッグログ
   * @param {string} message - ログメッセージ
   * @param {*} data - 追加データ（オプション）
   */
  App.logDebug = function(message, data) {
    addLog('debug', message, data);
  };

  /**
   * 情報ログ
   * @param {string} message - ログメッセージ
   * @param {*} data - 追加データ（オプション）
   */
  App.logInfo = function(message, data) {
    addLog('info', message, data);
  };

  /**
   * 警告ログ
   * @param {string} message - ログメッセージ
   * @param {*} data - 追加データ（オプション）
   */
  App.logWarn = function(message, data) {
    addLog('warn', message, data);
  };

  /**
   * エラーログ
   * @param {string} message - ログメッセージ
   * @param {*} data - 追加データ（オプション）
   */
  App.logError = function(message, data) {
    addLog('error', message, data);
  };

  /**
   * ログ一覧を取得
   * @returns {Array<LogEntry>} ログエントリの配列
   */
  App.getLogs = function() {
    return [...logs];
  };

  /**
   * ログをクリア
   */
  App.clearLogs = function() {
    logs.length = 0;
    if (App.renderLogs) {
      App.renderLogs();
    }
  };

  /**
   * ログをフィルタリングして取得
   * @param {string} level - フィルタするログレベル（オプション）
   * @returns {Array<LogEntry>} フィルタされたログエントリの配列
   */
  App.getFilteredLogs = function(level) {
    if (!level) {
      return App.getLogs();
    }
    return logs.filter(log => log.level === level);
  };

  /**
   * ログUIを描画
   */
  App.renderLogs = function() {
    const logContentEl = App.el?.logContent;
    if (!logContentEl) return;

    const allLogs = App.getLogs();
    
    // ログが空の場合
    if (allLogs.length === 0) {
      logContentEl.innerHTML = '<div class="log-empty">ログがありません</div>';
      return;
    }

    // ログを逆順（新しいものが上）で表示
    const reversedLogs = [...allLogs].reverse();
    
    logContentEl.innerHTML = reversedLogs.map(log => {
      const levelClass = `log-entry-${log.level}`;
      const levelLabel = {
        debug: '🐛 DEBUG',
        info: 'ℹ️ INFO',
        warn: '⚠️ WARN',
        error: '❌ ERROR'
      }[log.level] || log.level.toUpperCase();

      let dataHtml = '';
      if (log.data !== undefined) {
        try {
          const dataStr = typeof log.data === 'object' 
            ? JSON.stringify(log.data, null, 2)
            : String(log.data);
          dataHtml = `<pre class="log-data">${escapeHtml(dataStr)}</pre>`;
        } catch (e) {
          dataHtml = `<pre class="log-data">[データの表示に失敗]</pre>`;
        }
      }

      return `
        <div class="log-entry ${levelClass}">
          <div class="log-header-inner">
            <span class="log-level">${levelLabel}</span>
            <span class="log-timestamp">${log.timestamp}</span>
          </div>
          <div class="log-message">${escapeHtml(log.message)}</div>
          ${dataHtml}
        </div>
      `;
    }).join('');
  };

  /**
   * HTMLエスケープ
   * @param {string} text - エスケープするテキスト
   * @returns {string} エスケープされたテキスト
   */
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * ログパネルを表示/非表示
   */
  App.toggleLogPanel = function() {
    const panel = App.el?.logPanel;
    const overlay = App.el?.logOverlay;
    if (!panel) return;

    const isOpen = panel.classList.contains('open');
    if (!isOpen) {
      App.openPanel(panel, overlay);
      App.renderLogs();
    } else {
      App.closeLogPanel();
    }
  };

  /**
   * ログパネルを閉じる
   */
  App.closeLogPanel = function() {
    const panel = App.el?.logPanel;
    const overlay = App.el?.logOverlay;
    App.closePanel(panel, overlay);
  };

})();

