/**
 * ユーティリティ関数
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /** @param {string} raw */
  App.trimTrailingSlashes = function(raw) {
    return String(raw || "").replace(/\/+$/, "");
  };

  /** @param {string} text */
  App.safeJSONParse = function(text, fallback) {
    try {
      return JSON.parse(text);
    } catch {
      return fallback;
    }
  };

  /** @param {unknown} err */
  App.isLikelyServerOffline = function(err) {
    if (!err) return false;
    const msg = String(err);
    return err.name === "TypeError" || msg.includes("Failed to fetch") || msg.includes("NetworkError");
  };

  /**
   * テキストエリアの高さを内容に合わせて伸縮させる
   * @param {HTMLTextAreaElement} ta
   */
  App.autoResizeTextarea = function(ta) {
    ta.style.height = `${App.LIMITS.MIN_TEXTAREA_PX}px`;
    const newHeight = Math.min(ta.scrollHeight, App.LIMITS.MAX_TEXTAREA_PX);
    ta.style.height = `${newHeight}px`;
  };

  /**
   * チャットを最下部にスクロール
   * @param {HTMLElement} chatElement
   */
  App.scrollToBottom = function(chatElement) {
    chatElement.scrollTop = chatElement.scrollHeight;
  };

})();
