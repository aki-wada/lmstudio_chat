/**
 * JSDoc型定義
 * 
 * このファイルは型情報のみを提供し、実行時には使用されません。
 */

(function() {
  "use strict";

  /**
   * メッセージの役割
   * @typedef {"user"|"assistant"|"system"} Role
   */

  /**
   * 保存されたメッセージ
   * @typedef {Object} StoredMessage
   * @property {Role} role - メッセージの役割
   * @property {string} content - メッセージ内容
   * @property {string=} imageData - user添付画像（DataURL、オプション）
   */

  /**
   * アプリケーション設定
   * @typedef {Object} Settings
   * @property {string} baseUrl - APIベースURL
   * @property {string} apiKey - APIキー
   * @property {string=} model - 選択されたモデルID（オプション）
   * @property {number} temperature - 温度パラメータ（0-2）
   * @property {number} maxTokens - 最大トークン数
   * @property {string} systemPrompt - システムプロンプト
   * @property {"concise"|"standard"|"detailed"|"professional"} responseStyle - 応答スタイル
   * @property {string=} userLevel - ユーザーレベル（オプション）
   * @property {string=} userProfession - ユーザーの職業（オプション）
   * @property {string=} userInterests - ユーザーの興味（オプション）
   * @property {boolean} darkMode - ダークモード有効フラグ
   */

  /**
   * ファイルデータ
   * @typedef {Object} FileData
   * @property {string} id - ファイルID
   * @property {string} name - ファイル名
   * @property {string} type - MIMEタイプ
   * @property {"image"|"document"} category - ファイルカテゴリ
   * @property {string} data - DataURL（画像）またはBase64（その他）
   * @property {number} size - ファイルサイズ（バイト）
   * @property {number} uploadedAt - アップロード日時（タイムスタンプ）
   * @property {File|null} fileObject - 元のFileオブジェクト（PDFなど、オプション）
   */

  /**
   * モデルデータ（/v1/models レスポンス）
   * @typedef {Object} ModelData
   * @property {string} id - モデルID
   * @property {Object=} capabilities - モデルの機能情報（オプション）
   * @property {boolean=} capabilities.vision - 画像対応フラグ（OpenAI形式）
   * @property {boolean=} capabilities.multimodal - マルチモーダル対応フラグ（LM Studio形式）
   */

  /**
   * ランタイム状態
   * @typedef {Object} RuntimeState
   * @property {AbortController|null} abortController - 停止用コントローラー
   * @property {Set<string>} availableModels - 利用可能なモデルIDのセット
   * @property {Map<string,boolean>} modelVisionCapableMap - モデルID -> 画像対応フラグのマップ
   * @property {Array<ModelData>} allModelData - 全モデルデータ
   */

  /**
   * コンテンツ配列の要素
   * @typedef {Object} ContentItem
   * @property {"text"|"image_url"|"input_file"} type - コンテンツタイプ
   * @property {string=} text - テキスト内容（type="text"の場合）
   * @property {Object=} image_url - 画像URLオブジェクト（type="image_url"の場合）
   * @property {string=} image_url.url - 画像URL（DataURL）
   * @property {string=} file_id - ファイルID（type="input_file"の場合）
   */

})();
