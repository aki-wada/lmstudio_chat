/**
 * パネル管理の共通機能
 * パネルの開閉、オーバーレイクリック処理などを統一管理
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /**
   * パネルを開く
   * @param {HTMLElement} panel - パネル要素
   * @param {HTMLElement} overlay - オーバーレイ要素（オプション）
   * @param {Array<HTMLElement>} closeOtherPanels - 同時に閉じる他のパネル（オプション）
   */
  App.openPanel = function(panel, overlay, closeOtherPanels = []) {
    if (!panel) return;

    // 他のパネルを閉じる
    closeOtherPanels.forEach(otherPanel => {
      if (otherPanel) {
        otherPanel.classList.remove("open");
      }
    });

    // オーバーレイを開く
    if (overlay) {
      overlay.classList.add("open");
    }

    // パネルを開く
    panel.classList.add("open");

    // 背景のスクロールを無効化
    document.body.style.overflow = "hidden";
  };

  /**
   * パネルを閉じる
   * @param {HTMLElement} panel - パネル要素
   * @param {HTMLElement} overlay - オーバーレイ要素（オプション）
   */
  App.closePanel = function(panel, overlay) {
    if (!panel) return;

    // パネルを閉じる
    panel.classList.remove("open");

    // オーバーレイを閉じる
    if (overlay) {
      overlay.classList.remove("open");
    }

    // 背景のスクロールを有効化（他のパネルが開いていない場合のみ）
    const anyPanelOpen = document.querySelector(".settings-panel.open, .preset-panel.open, .preset-edit-panel.open, .file-list-panel.open, .log-panel.open");
    if (!anyPanelOpen) {
      document.body.style.overflow = "";
    }
  };

  /**
   * パネルの開閉をトグル
   * @param {HTMLElement} panel - パネル要素
   * @param {HTMLElement} overlay - オーバーレイ要素（オプション）
   * @param {Array<HTMLElement>} closeOtherPanels - 同時に閉じる他のパネル（オプション）
   */
  App.togglePanel = function(panel, overlay, closeOtherPanels = []) {
    if (!panel) return;

    const isOpen = panel.classList.contains("open");
    if (isOpen) {
      App.closePanel(panel, overlay);
    } else {
      App.openPanel(panel, overlay, closeOtherPanels);
    }
  };

  /**
   * オーバーレイクリックでパネルを閉じるイベントを設定
   * @param {HTMLElement} overlay - オーバーレイ要素
   * @param {HTMLElement} panel - パネル要素
   * @param {HTMLElement} panelContainer - パネルコンテナ要素（クリック伝播を防ぐため）
   */
  App.setupOverlayClickToClose = function(overlay, panel, panelContainer) {
    if (!overlay || !panel) return;

    overlay.addEventListener("click", (e) => {
      // オーバーレイ自体をクリックした場合のみ閉じる
      if (e.target === overlay) {
        App.closePanel(panel, overlay);
      }
    });

    // パネル内のクリックがオーバーレイに伝播しないようにする
    if (panelContainer) {
      panelContainer.addEventListener("click", (e) => {
        e.stopPropagation();
      });
    }
  };

})();

