/**
 * API通信（モデル取得、送信、ストリーミング）
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /**
   * /v1/models を叩いて <select> を更新する
   * - "embedding系" を除外
   * - 以前の選択 / fallback を考慮して選択を決定
   * @param {Set<string>} availableModels
   * @param {Map<string,boolean>} modelVisionCapableMap - モデルID -> 画像対応フラグのMap
   * @param {Array} allModelDataRef - モデルデータを保存する配列への参照
   */
  App.refreshModels = async function(availableModels, modelVisionCapableMap, allModelDataRef) {
    availableModels.clear();

    const settings = App.getSettings();
    const base = App.trimTrailingSlashes(settings.baseUrl || App.el.baseUrl.value.trim());
    const key = settings.apiKey || App.el.apiKey.value.trim();

    // UI: Loading...
    App.el.modelSelect.innerHTML = "<option>Loading...</option>";

    try {
      const r = await fetch(`${base}/models`, {
        headers: { Authorization: `Bearer ${key}` },
      });
      if (!r.ok) throw new Error(String(r.status));

      const data = await r.json();
      const allModelData = data.data || [];
      const allModels = allModelData.map(m => m.id);

      // モデルデータを保存（capabilities情報を含む）
      if (allModelDataRef) {
        allModelDataRef.length = 0;
        allModelDataRef.push(...allModelData);
      }

      // 埋め込みモデル（text embedding）を除外
      const list = allModels.filter(id => {
        const lower = String(id).toLowerCase();
        return !App.EMBEDDING_KEYWORDS.some(k => lower.includes(k));
      });

      // build options
      App.el.modelSelect.innerHTML = "";
      list.forEach(id => {
        const opt = document.createElement("option");
        opt.value = id;
        opt.textContent = id.replace(/^.*\//, "");
        App.el.modelSelect.appendChild(opt);
        availableModels.add(id);
      });

      // 画像対応情報を保存
      if (modelVisionCapableMap) {
        modelVisionCapableMap.clear();
        
        // 保存された画像対応情報を読み込み（実際の送信結果から記録されたもの）
        const savedCapabilities = App.loadModelVisionCapabilities();
        
        list.forEach(id => {
          // 保存された情報を優先（実際の送信結果から記録されたもの）
          let isVisionCapable = savedCapabilities[id];
          
          // 保存された情報がない場合、自動判定
          if (isVisionCapable === undefined) {
            isVisionCapable = App.isModelVisionCapable(id, allModelData);
          }
          
          modelVisionCapableMap.set(id, isVisionCapable);
          
          // 各モデルの判定結果をログ出力
          const source = savedCapabilities[id] !== undefined ? "保存済み" : "自動判定";
          App.logDebug(`[モデル一覧] ${id}: 画像対応=${isVisionCapable} (${source})`);
        });
      }
      
      // 全モデルデータをログ出力
      App.logDebug(`[モデル一覧] 全モデルデータ`, allModelData);
      App.logDebug(`[モデル一覧] 画像対応マップ`, Array.from(modelVisionCapableMap?.entries() || []));

      // selection strategy: saved → some known fallbacks → first
      const preferred = settings.model;
      const fallbacks = [
        preferred,
        "google/gemma-3-12b",
        "llama-3.1-swallow-8b-instruct-v0.5",
        "qwen/qwen3-4b-2507",
        list[0],
      ].filter(Boolean);

      let chosen = null;
      for (const cand of fallbacks) {
        if (availableModels.has(cand)) { chosen = cand; break; }
      }
      if (chosen) App.el.modelSelect.value = chosen;

      // 設定を保存（モデル選択を含む）
      const newSettings = {
        ...settings,
        model: App.el.modelSelect.value,
      };
      App.setSettings(newSettings);
    } catch (e) {
      App.el.modelSelect.innerHTML = "";
      if (App.isLikelyServerOffline(e)) {
        App.notify("⚠️ LM Studioが起動していないか、Base URLに接続できません。LM Studioを起動して再試行してください。");
      } else {
        App.notify("⚠️ モデル一覧を取得できませんでした。Base/KeyとServer状態を確認してください。");
      }
    }
  };

  /**
   * モデルIDから画像対応かどうかを判定
   * @param {string} modelId
   * @param {Array} modelData - /v1/models のレスポンスのdata配列（オプション、capabilities情報がある場合）
   * @returns {boolean}
   */
  App.isModelVisionCapable = function(modelId, modelData) {
    if (!modelId) return false;

    // APIレスポンスにcapabilities情報がある場合はそれを使用（優先）
    if (modelData && Array.isArray(modelData)) {
      const model = modelData.find(m => m.id === modelId);
      if (model) {
        // モデル情報をログ出力
        App.logDebug(`[isModelVisionCapable] モデル情報 [${modelId}]`, model);
        App.logDebug(`[isModelVisionCapable] model.capabilities`, model.capabilities);

        // OpenAI形式: model.capabilities?.vision
        if (model.capabilities?.vision === true) {
          App.logDebug(`[isModelVisionCapable] capabilities.vision = true`);
          return true;
        }
        // LM Studio形式: model.capabilities?.multimodal など
        if (model.capabilities?.multimodal === true) {
          App.logDebug(`[isModelVisionCapable] capabilities.multimodal = true`);
          return true;
        }
        // その他の形式: model.vision, model.supports_vision など
        if (model.vision === true || model.supports_vision === true) {
          App.logDebug(`[isModelVisionCapable] vision/supports_vision = true`);
          return true;
        }
        // LM Studioのモデル情報に画像対応を示すフィールドがある場合
        if (model.supports_image_input === true || model.supports_images === true) {
          App.logDebug(`[isModelVisionCapable] supports_image_input/images = true`);
          return true;
        }
        
        // LM Studioのモデルオブジェクトに画像対応を示す可能性のあるフィールドを広くチェック
        // モデルオブジェクト全体を文字列化して、画像関連のキーワードを探す
        const modelStr = JSON.stringify(model).toLowerCase();
        if (modelStr.includes('vision') || modelStr.includes('image') || modelStr.includes('multimodal')) {
          // ただし、falseやnullの場合は除外
          if (!modelStr.includes('"vision":false') && !modelStr.includes('"image":false') && 
              !modelStr.includes('"vision":null') && !modelStr.includes('"image":null')) {
            App.logDebug(`[isModelVisionCapable] 文字列検索で画像対応を検出`);
            return true;
          }
        }
        
        // モデルオブジェクトのすべてのキーをチェック
        for (const key in model) {
          const keyLower = key.toLowerCase();
          const value = model[key];
          if ((keyLower.includes('vision') || keyLower.includes('image') || keyLower.includes('multimodal')) && 
              (value === true || (typeof value === 'object' && value !== null && Object.keys(value).length > 0))) {
            App.logDebug(`[isModelVisionCapable] キー「${key}」で画像対応を検出`, value);
            return true;
          }
        }
      } else {
        App.logWarn(`[isModelVisionCapable] モデル「${modelId}」がmodelDataに見つかりません`);
      }
    } else {
      App.logWarn(`[isModelVisionCapable] modelDataが空または無効です`, modelData);
    }

    // モデル名からキーワードで判定（フォールバック1）
    const lower = String(modelId).toLowerCase();
    const keywordMatch = App.VISION_KEYWORDS.some(keyword => lower.includes(keyword.toLowerCase()));
    if (keywordMatch) {
      App.logDebug(`[isModelVisionCapable] キーワード判定で画像対応を検出`, keywordMatch);
      return true;
    }
    
    // モデル名パターンで判定（フォールバック2）
    // APIレスポンスにcapabilities情報がない場合でも、特定のモデル名パターンから判定
    if (App.VISION_MODEL_PATTERNS && App.VISION_MODEL_PATTERNS.length > 0) {
      const patternMatch = App.VISION_MODEL_PATTERNS.some(pattern => pattern.test(modelId));
      if (patternMatch) {
        App.logDebug(`[isModelVisionCapable] パターン判定で画像対応を検出: ${modelId}`);
        return true;
      }
    }
    
    App.logDebug(`[isModelVisionCapable] すべての判定方法で画像非対応と判定`);
    return false;
  };

  /**
   * 送信前に、選択モデルが /v1/models に存在するかを確認する
   * @param {string} modelId
   * @param {Set<string>} availableModels
   */
  App.validateModelExists = function(modelId, availableModels) {
    return availableModels.size > 0 && availableModels.has(modelId);
  };

  /**
   * ファイルを /v1/files エンドポイントにアップロードしてファイルIDを取得
   * @param {File} file - アップロードするファイル
   * @param {string} base - APIベースURL
   * @param {string} key - APIキー
   * @returns {Promise<string>} ファイルID（例: "file-xxx"）
   */
  App.uploadFileToAPI = async function(file, base, key) {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("purpose", "assistants");

    const res = await fetch(`${base}/files`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
      },
      body: formData,
    });

    if (!res.ok) {
      const errorText = await res.text().catch(() => "");
      let errorMsg = `ファイルアップロードエラー: ${res.status}`;
      try {
        const errorJson = JSON.parse(errorText);
        errorMsg += ` - ${errorJson.error?.message || errorText}`;
      } catch {
        if (errorText) errorMsg += ` - ${errorText}`;
      }
      throw new Error(errorMsg);
    }

    const data = await res.json();
    if (!data.id) {
      throw new Error("ファイルアップロードレスポンスにIDが含まれていません");
    }
    return data.id;
  };

  /**
   * SSEイベントをパースしてdeltaを抽出
   * @param {string} eventText - SSEイベントテキスト
   * @param {function(string): void} onDelta - delta文字列を受け取るコールバック関数
   * @param {function(): void} onDone - 完了時に呼ばれるコールバック関数
   * @returns {boolean} [DONE]を受信した場合はtrue
   */
  App.parseSSEEvent = function(eventText, onDelta, onDone) {
    const lines = eventText
      .split("\n")
      .filter(l => l.startsWith("data: "))
      .map(l => l.slice(6));
    
    if (!lines.length) return false;
    
    const payload = lines.join("\n");
    if (payload === "[DONE]") {
      onDone();
      return true;
    }
    
    try {
      const j = JSON.parse(payload);
      const delta =
        j.choices?.[0]?.delta?.content ??
        j.choices?.[0]?.text ??
        "";
      if (delta) onDelta(delta);
    } catch {
      // 不完全JSONは無視（次チャンクで完成する可能性がある）
    }
    
    return false;
  };

  /**
   * バッファ内のSSEイベントを処理
   * @param {string} buf - バッファ文字列
   * @param {function(string): void} onDelta - delta文字列を受け取るコールバック関数
   * @param {function(): void} onDone - 完了時に呼ばれるコールバック関数
   * @returns {boolean} [DONE]を受信した場合はtrue
   */
  App.processSSEBuffer = function(buf, onDelta, onDone) {
    if (!buf.trim()) return false;
    
    const events = buf.split("\n\n");
    for (const ev of events) {
      if (App.parseSSEEvent(ev, onDelta, onDone)) {
        return true;
      }
    }
    return false;
  };

  /**
   * SSEストリームを読み取り、delta文字列を順次 callback へ渡す
   * @param {ReadableStreamDefaultReader<Uint8Array>} reader
   * @param {function(string): void} onDelta - delta文字列を受け取るコールバック関数
   * @param {function(): void} onDone - 完了時に呼ばれるコールバック関数
   * @param {number} timeoutMs - タイムアウト時間（ミリ秒）
   */
  App.consumeSSE = async function(reader, onDelta, onDone, timeoutMs) {
    const decoder = new TextDecoder("utf-8");
    let buf = "";
    const timeout = timeoutMs || App.LIMITS.SSE_TIMEOUT_MS;
    let lastDataTime = Date.now();
    let hasReceivedData = false;

    // タイムアウト監視
    let timeoutReached = false;
    const timeoutId = setInterval(() => {
      const elapsed = Date.now() - lastDataTime;
      if (elapsed > timeout && !hasReceivedData) {
        // データが全く来ていない場合、タイムアウト
        timeoutReached = true;
        clearInterval(timeoutId);
        reader.cancel().catch(() => {}); // エラーを無視
      } else if (elapsed > timeout * 2 && hasReceivedData) {
        // データが来ていたが、その後長時間来ていない場合もタイムアウト
        timeoutReached = true;
        clearInterval(timeoutId);
        reader.cancel().catch(() => {}); // エラーを無視
      }
    }, App.TIMING?.SSE_TIMEOUT_CHECK_INTERVAL_MS || 1000);

    try {
      while (true) {
        // タイムアウトチェック
        if (timeoutReached) {
          clearInterval(timeoutId);
          throw new Error("SSE_TIMEOUT");
        }

        let readResult;
        try {
          readResult = await reader.read();
        } catch (readError) {
          // ERR_INCOMPLETE_CHUNKED_ENCODINGなどのネットワークエラーを処理
          clearInterval(timeoutId);
          App.logError(`[consumeSSE] ストリーム読み取りエラー`, readError);
          App.logError(`[consumeSSE] エラー詳細: name=${readError.name}, message=${readError.message}, hasReceivedData=${hasReceivedData}, buf.length=${buf.length}`);
          // 既に受信したデータがあれば処理する
          if (hasReceivedData && buf.trim()) {
            App.processSSEBuffer(buf, onDelta, onDone);
            // データが受信されていれば正常終了として扱う
            onDone();
            return;
          }
          // データが全く受信されていない場合はエラーを再スロー
          throw readError;
        }

        const { value, done } = readResult;
        if (done) {
          // ストリームが正常に終了した場合、残りのバッファを処理
          clearInterval(timeoutId);
          App.logDebug(`[consumeSSE] ストリーム終了: hasReceivedData=${hasReceivedData}, buf.length=${buf.length}`);
          
          // バッファにデータがある場合は処理
          if (buf.trim()) {
            const doneReceived = App.processSSEBuffer(buf, onDelta, onDone);
            if (doneReceived) {
              App.logDebug(`[consumeSSE] [DONE]を受信、onDone()を呼び出しました`);
              return;
            }
          }
          
          // ストリームが正常に終了した場合、onDoneを呼ぶ（[DONE]が来なかった場合でも）
          // データが全く受信されていない場合でも、onDone()を呼ぶ必要がある
          // （そうしないと、履歴保存やUI更新が行われない）
          App.logDebug(`[consumeSSE] ストリーム終了（done=true）、onDone()を呼び出します: hasReceivedData=${hasReceivedData}, buf.length=${buf.length}`);
          onDone();
          return;
        }

        // valueがundefinedの場合はスキップ（一部のモデルで発生する可能性がある）
        if (!value) {
          App.logWarn(`[consumeSSE] valueがundefinedです。スキップします。`);
          continue;
        }

        hasReceivedData = true;
        lastDataTime = Date.now();
        buf += decoder.decode(value, { stream: true });

        // SSE: event delimiter is blank line
        const events = buf.split("\n\n");
        buf = events.pop() || "";

        // 完全なイベントを処理
        for (const ev of events) {
          if (App.parseSSEEvent(ev, onDelta, onDone)) {
            clearInterval(timeoutId);
            return;
          }
        }
      }
      // このコードには到達しないはず（done === trueの場合は既にreturnしている）
      clearInterval(timeoutId);
    } catch (e) {
      clearInterval(timeoutId);
      if (e && e.message === "SSE_TIMEOUT") {
        throw e;
      }
      // その他のエラーも再スロー
      throw e;
    }
  };

  /**
   * PDFファイルをアップロードしてファイルIDを取得
   * @param {Array<Object>} pdfFiles - PDFファイルの配列
   * @param {string} base - APIベースURL
   * @param {string} key - APIキー
   * @param {HTMLElement} currentMsgDiv - 現在のメッセージ要素
   * @returns {Promise<Array<{fileId: string, name: string}>>} ファイルIDと名前の配列
   */
  App.uploadPdfFiles = async function(pdfFiles, base, key, currentMsgDiv) {
    const pdfFileIds = [];
    for (const pdfFile of pdfFiles) {
      try {
        App.notify(`📤 PDFファイル「${pdfFile.name}」をアップロードしています...`);
        const fileId = await App.uploadFileToAPI(pdfFile.fileObject, base, key);
        pdfFileIds.push({ fileId, name: pdfFile.name });
        App.notify(`✅ PDFファイル「${pdfFile.name}」をアップロードしました`);
      } catch (uploadError) {
        const contentEl = currentMsgDiv?.querySelector(".message-content");
        if (contentEl) {
          contentEl.textContent = `ファイルアップロードエラー: ${uploadError.message || uploadError}`;
        }
        App.notify(`⚠️ ファイル「${pdfFile.name}」のアップロードに失敗しました: ${uploadError.message || uploadError}`);
        throw uploadError;
      }
    }
    return pdfFileIds;
  };

  /**
   * テキストファイルの内容を読み込んでcontentArrayに追加
   * @param {Array<Object>} textFiles - テキストファイルの配列
   * @param {Array<Object>} contentArray - コンテンツ配列（参照渡し）
   */
  App.processTextFiles = function(textFiles, contentArray) {
    for (const textFile of textFiles) {
      try {
        const base64Data = textFile.data.split(',')[1];
        const binaryString = atob(base64Data);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const textContent = new TextDecoder('utf-8').decode(bytes);
        
        const fileContent = `\n\n---\n📄 **添付ファイル: ${textFile.name}**\n\`\`\`\n${textContent}\n\`\`\``;
        
        if (contentArray.length > 0 && contentArray[0].type === "text") {
          contentArray[0].text += fileContent;
        } else {
          contentArray.push({ type: "text", text: fileContent });
        }
      } catch (error) {
        App.logError("テキストファイルの読み込みエラー", error);
        // エラーが発生しても続行
      }
    }
  };

  /**
   * 選択されたファイルからcontentArrayを構築
   * @param {Array<Object>} selectedFiles - 選択されたファイルの配列
   * @param {string} text - ユーザーのテキスト入力
   * @param {string} base - APIベースURL
   * @param {string} key - APIキー
   * @param {HTMLElement} currentMsgDiv - 現在のメッセージ要素
   * @returns {Promise<Array<Object>>} contentArray
   */
  App.buildContentArray = async function(selectedFiles, text, base, key, currentMsgDiv) {
    const contentArray = [];
    
    // テキストがある場合は追加
    if (text && text.trim()) {
      contentArray.push({ type: "text", text: text.trim() });
    }

    // PDFファイルをアップロード
    const pdfFiles = selectedFiles.filter(f => f.name.toLowerCase().endsWith(".pdf") && f.fileObject);
    const pdfFileIds = await App.uploadPdfFiles(pdfFiles, base, key, currentMsgDiv);

    // テキストファイルを処理（PDF以外）
    const textFiles = selectedFiles.filter(f => 
      !f.name.toLowerCase().endsWith(".pdf") && 
      f.category === "document" &&
      f.data
    );
    App.processTextFiles(textFiles, contentArray);

    // PDFファイルをinput_fileとして追加
    for (const { fileId } of pdfFileIds) {
      contentArray.push({ 
        type: "input_file", 
        file_id: fileId 
      });
    }

    // 画像をimage_urlとして追加
    const imageFiles = selectedFiles.filter(f => f.category === "image" && f.data);
    for (const imageFile of imageFiles) {
      contentArray.push({ 
        type: "image_url", 
        image_url: { url: imageFile.data } 
      });
    }

    return contentArray;
  };

  /**
   * 送信ボタンとストップボタンのUI状態を更新
   * @param {boolean} isSending - 送信中かどうか
   */
  App.updateSendButtonState = function(isSending) {
    if (isSending) {
      App.el.sendBtn.style.display = 'none';
      App.el.stopBtn.style.display = 'flex';
      App.el.stopBtn.disabled = false;
    } else {
      App.el.stopBtn.style.display = 'none';
      App.el.sendBtn.style.display = 'flex';
      App.el.stopBtn.disabled = true;
      App.el.sendBtn.disabled = false;
    }
  };

  /**
   * APIエラーレスポンスを処理
   * @param {Response} res - レスポンスオブジェクト
   * @param {HTMLElement} currentMsgDiv - 現在のメッセージ要素
   * @param {string} model - モデルID
   * @returns {Promise<void>}
   */
  App.handleApiError = async function(res, currentMsgDiv, model) {
    App.logError(`[handleSend] APIエラー: モデル=${model}, status=${res.status}, statusText=${res.statusText}, ok=${res.ok}, body=${res.body ? "あり" : "なし"}`);
    const t = await res.text().catch(() => "");
    const contentEl = currentMsgDiv?.querySelector(".message-content");
    let errorMsg = `エラー:${res.status}`;
    
    if (t) {
          const maxLength = App.DISPLAY?.MAX_ERROR_TEXT_LENGTH || 200;
          App.logError(`[handleSend] エラーテキスト: ${t.substring(0, maxLength)}`);
      try {
        const errorJson = JSON.parse(t);
        const errorMessage = errorJson.error?.message || t;
        errorMsg += ` - ${errorMessage}`;
      } catch {
        errorMsg += ` - ${t}`;
      }
    }
    
    if (contentEl) contentEl.textContent = errorMsg;
    App.notify(`⚠️ APIエラー: ${res.status} - 詳細はメッセージを確認してください`);
  };

  /**
   * 例外エラーを処理してUIに表示
   * @param {Error} e - エラーオブジェクト
   * @param {HTMLElement} currentMsgDiv - 現在のメッセージ要素
   * @param {string} model - モデルID
   */
  App.handleSendError = function(e, currentMsgDiv, model) {
    const contentEl = currentMsgDiv?.querySelector(".message-content");
    
    App.logError(`[handleSend] エラー発生: モデル=${model}`, e);
    
    if (e && e.name === "AbortError") {
      if (contentEl) contentEl.innerHTML = marked.parse("⏹ **生成を停止しました。**");
    } else if (App.isLikelyServerOffline(e)) {
      if (contentEl) contentEl.textContent = "接続できませんでした。LM Studioが起動していない可能性があります。";
      App.notify("⚠️ LM Studioが起動していないか、Base URLに接続できません。LM Studioを起動して再試行してください。");
    } else if (e && e.message === "REQUEST_TIMEOUT") {
      if (contentEl) contentEl.textContent = "リクエストがタイムアウトしました。";
      App.notify("⚠️ リクエストがタイムアウトしました。");
    } else {
      if (contentEl) contentEl.textContent = `通信エラー: ${e}`;
    }
  };

  /**
   * 送信ボタンの本体
   * - 入力テキストを整形
   * - バリデーション（モデル存在）
   * - 逐次描画（... → streaming）
   * - 完了時に履歴へ保存
   * @param {Object} controller
   * @param {Set<string>} availableModels
   * @param {Map<string,boolean>} modelVisionCapableMap
   * @param {Array} allModelData - /v1/models のレスポンスのdata配列
   * @param {Function} strongClearPrompt
   */
  App.handleSend = async function(controller, availableModels, modelVisionCapableMap, allModelData, strongClearPrompt) {
    let text = App.el.prompt.value.trim();
    const selectedFiles = App.getQueuedFiles();
    
    // テキストまたはファイルが選択されている必要がある
    if (!text && selectedFiles.length === 0) return;

    const settings = App.getSettings();
    const base = App.trimTrailingSlashes(settings.baseUrl || App.el.baseUrl.value.trim());
    const key = settings.apiKey || App.el.apiKey.value.trim();
    const model = settings.model || App.el.modelSelect.value;

    if (!App.validateModelExists(model, availableModels)) {
      App.notify(`⚠️ 選択モデルが /v1/models に見つかりません: ${model}`);
      return;
    }
    
    // 表示用テキストを構築
    let displayText = text;
    if (selectedFiles.length > 0) {
      const fileNames = selectedFiles.map(f => f.name).join(", ");
      displayText = text ? `${text}\n\n📎 添付: ${fileNames}` : `📎 添付: ${fileNames}`;
    }
    
    App.appendMessage("user", displayText || "(ファイルのみ)", { save: true });
    strongClearPrompt();

    // assistant placeholder
    App.appendMessage("assistant", "...", { save: false });
    const currentMsgDiv = /** @type {HTMLDivElement} */ (App.el.chat.lastChild);

    controller.abortController = new AbortController();
    App.updateSendButtonState(true);

    try {
      // 選択されたファイルからcontentArrayを構築
      const contentArray = await App.buildContentArray(selectedFiles, text, base, key, currentMsgDiv);

      // userMessageを構築
      let userMessage;
      if (contentArray.length > 0) {
        userMessage = { role: "user", content: contentArray };
      } else {
        userMessage = { role: "user", content: text || "" };
      }

      // リクエストボディを構築
      const requestBody = {
        model,
        messages: [...App.buildConversation(false), userMessage],
        stream: true,
        temperature: parseFloat(App.el.temperature.value) || 0.7,
        max_tokens: parseInt(App.el.maxTokens.value, 10) || 2048,
      };

      // 送信後、キューをクリア
      App.clearFileQueue();
      App.renderFileList();

      // 送信内容をログに記録
      App.logDebug("送信するメッセージ", JSON.parse(JSON.stringify(userMessage)));
      App.logDebug("リクエストボディ", JSON.parse(JSON.stringify(requestBody)));

      // タイムアウト付きfetch
      const res = await Promise.race([
        fetch(`${base}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify(requestBody),
          signal: controller.abortController.signal,
        }),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error("REQUEST_TIMEOUT")), App.LIMITS.REQUEST_TIMEOUT_MS)
        )
      ]);

      if (!res.ok || !res.body) {
        await App.handleApiError(res, currentMsgDiv, model);
        return;
      }

      const reader = res.body.getReader();
      let content = "";

      App.logDebug(`[handleSend] ストリーム開始: モデル=${model}, Content-Type=${res.headers.get("content-type")}`);

      await App.consumeSSE(
        reader,
        (delta) => {
          content += delta;
          const contentEl = currentMsgDiv.querySelector(".message-content");
          if (contentEl) contentEl.innerHTML = marked.parse(content);
          App.scrollToBottom(App.el.chat);
        },
        () => {
          App.logDebug(`[handleSend] onDone()コールバック実行: モデル=${model}, 受信文字数=${content.length}`);
          const contentEl = currentMsgDiv.querySelector(".message-content");
          if (!contentEl) {
            App.logWarn(`[handleSend] contentElが見つかりません`);
            return;
          }
          App.logDebug(`[handleSend] メッセージを更新します: content.length=${content.length}`);
          contentEl.innerHTML = marked.parse(content || "(空応答)");

          // Copy機能用のdataset更新
          currentMsgDiv.dataset.content = content;

          // 履歴へ保存
          App.addMessage({ role: "assistant", content });

          // ストップボタンを非表示、送信ボタンを表示
          App.el.stopBtn.style.display = 'none';
          App.el.sendBtn.style.display = 'flex';
          App.el.stopBtn.disabled = true;
          controller.abortController = null;
        },
        App.LIMITS.SSE_TIMEOUT_MS
      );

    } catch (e) {
      App.handleSendError(e, currentMsgDiv, model);
    } finally {
      App.updateSendButtonState(false);
      if (controller.abortController) {
        controller.abortController = null;
      }
    }
  };

  App.handleStop = function(controller) {
    if (controller.abortController) controller.abortController.abort();
  };

})();
