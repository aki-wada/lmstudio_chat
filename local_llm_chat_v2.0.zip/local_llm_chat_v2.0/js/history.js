/**
 * 履歴のエクスポートとクリア
 */

(function() {
  "use strict";

  window.App = window.App || {};

  App.exportHistory = function() {
    const messages = App.getMessages();
    const blob = new Blob([JSON.stringify(messages, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = `chat_history_${new Date().toISOString().slice(0, 19)}.json`;
    a.click();

    URL.revokeObjectURL(url);
  };

  App.clearHistory = function() {
    if (!confirm("履歴をすべて削除しますか？")) return;
    App.clearMessages();
    App.el.chat.innerHTML = "";
    App.notify("🗑 会話履歴を削除しました。");
  };

})();
