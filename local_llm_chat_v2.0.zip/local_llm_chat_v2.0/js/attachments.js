/**
 * 添付ファイル処理（画像、PDF、テキスト）
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /**
   * 画像を DataURL(base64) にして state へ保持
   * @param {File} file
   */
  App.loadImageAsDataURL = function(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (ev) => resolve(ev.target.result);
      reader.onerror = () => reject(new Error("画像の読み込みに失敗しました"));
      reader.readAsDataURL(file);
    });
  };

  /**
   * ファイルをBase64エンコードしてDataURLとして読み込む
   * @param {File} file
   * @returns {Promise<string>} DataURL形式（data:application/pdf;base64,...）
   */
  App.loadFileAsDataURL = function(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (ev) => resolve(ev.target.result);
      reader.onerror = () => reject(new Error("ファイルの読み込みに失敗しました"));
      reader.readAsDataURL(file);
    });
  };

  /**
   * ファイルアップロード処理（画像とファイルの両方に対応）
   * @param {File|FileList} files - アップロードするファイル
   */
  App.handleFileUpload = async function(files) {
    if (!files) return;

    // FileListの場合は配列に変換
    const fileArray = files instanceof FileList ? Array.from(files) : [files];

    for (const file of fileArray) {
      // 画像ファイルの場合
      if (file.type.startsWith("image/")) {
        if (file.size > App.LIMITS.IMAGE_MAX_BYTES) {
          App.notify(`⚠️ 画像「${file.name}」のサイズは20MB以下にしてください`);
          continue;
        }

        try {
          await App.saveUploadedFile(file);
          App.notify(`✅ 画像「${file.name}」をアップロードしました`);
        } catch (error) {
          App.logError("画像のアップロードエラー", error);
          App.notify(`⚠️ 画像「${file.name}」のアップロードに失敗しました`);
        }
      } else {
        // その他のファイルの場合
        const isPDF = file.name.toLowerCase().endsWith(".pdf");
        const sizeLimit = isPDF ? App.LIMITS.PDF_MAX_BYTES : App.LIMITS.FILE_MAX_BYTES;
        const sizeLimitText = isPDF ? "5MB" : "1MB";

        if (file.size > sizeLimit) {
          App.notify(`⚠️ ファイル「${file.name}」のサイズは${sizeLimitText}以下にしてください`);
          continue;
        }

        try {
          await App.saveUploadedFile(file);
          App.notify(`✅ ファイル「${file.name}」をアップロードしました`);
        } catch (error) {
          App.logError("ファイルのアップロードエラー", error);
          App.notify(`⚠️ ファイル「${file.name}」のアップロードに失敗しました`);
        }
      }
    }

    // 入力欄をクリア
    if (App.el.fileUploadInput) {
      App.el.fileUploadInput.value = "";
    }
  };

  /**
   * PDF.js で全ページからテキスト抽出する（シンプルに items.str を連結）
   * @param {ArrayBuffer} arrayBuffer
   * @returns {Promise<{text:string, pages:number}>}
   */
  App.extractTextFromPdf = async function(arrayBuffer) {
    if (typeof pdfjsLib === "undefined") {
      throw new Error("PDF.jsが読み込まれていません");
    }

    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;

    let fullText = "";
    const numPages = pdf.numPages;

    for (let pageNum = 1; pageNum <= numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map(item => item.str).join(" ");
      fullText += `\n--- ページ ${pageNum} ---\n${pageText}\n`;
    }

    return { text: fullText.trim(), pages: numPages };
  };

  /** @param {File} file */
  App.readTextFile = function(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (ev) => resolve(ev.target.result);
      reader.onerror = () => reject(new Error("ファイルの読み込みに失敗しました"));
      reader.readAsText(file);
    });
  };

  /** @param {File} file */
  App.readArrayBuffer = function(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (ev) => resolve(ev.target.result);
      reader.onerror = () => reject(new Error("PDFファイルの読み込みに失敗しました"));
      reader.readAsArrayBuffer(file);
    });
  };


})();
