/**
 * DOM要素参照（Single Source of Truth）
 */

(function() {
  "use strict";

  window.App = window.App || {};

  App.el = Object.freeze({
    // main
    chat: document.getElementById("chat"),
    modelSelect: document.getElementById("modelSelect"),
    prompt: document.getElementById("prompt"),
    sendBtn: document.getElementById("send"),
    stopBtn: document.getElementById("stopBtn"),
    refreshBtn: document.getElementById("refreshBtn"),
    clearBtn: document.getElementById("clearBtn"),
    exportBtn: document.getElementById("exportBtn"),
    fileListBtn: document.getElementById("fileListBtn"),

    // settings
    settingsBtn: document.getElementById("settingsBtn"),
    settingsPanel: document.getElementById("settingsPanel"),
    settingsOverlay: document.getElementById("settingsOverlay"),
    closeSettingsBtn: document.getElementById("closeSettingsBtn"),
    baseUrl: document.getElementById("baseUrl"),
    apiKey: document.getElementById("apiKey"),
    temperature: document.getElementById("temperature"),
    tempValue: document.getElementById("tempValue"),
    maxTokens: document.getElementById("maxTokens"),
    systemPrompt: document.getElementById("systemPrompt"),
    responseStyle: document.getElementById("responseStyle"),
    userLevel: document.getElementById("userLevel"),
    userProfession: document.getElementById("userProfession"),
    userInterests: document.getElementById("userInterests"),
    darkModeToggle: document.getElementById("darkModeToggle"),
    resetSettingsBtn: document.getElementById("resetSettingsBtn"),
    clearAllDataBtn: document.getElementById("clearAllDataBtn"),

    // attachments
    fileUploadInput: document.getElementById("fileUploadInput"),

    // file list
    fileListPanel: document.getElementById("fileListPanel"),
    fileListOverlay: document.getElementById("fileListOverlay"),
    fileListHeader: document.querySelector(".file-list-header"),
    fileListContent: document.getElementById("fileListContent"),
    closeFileListBtn: document.getElementById("closeFileListBtn"),
    imageFileList: document.getElementById("imageFileList"),
    documentFileList: document.getElementById("documentFileList"),

    // file queue
    fileQueuePanel: document.getElementById("fileQueuePanel"),
    fileQueueContent: document.getElementById("fileQueueContent"),
    fileQueueList: document.getElementById("fileQueueList"),
    clearQueueBtn: document.getElementById("clearQueueBtn"),

    // preset (panel + editor)
    presetPanel: document.getElementById("presetPanel"),
    presetBtn: document.getElementById("presetBtn"),
    closePresetBtn: document.getElementById("closePresetBtn"),
    presetEditOverlay: document.getElementById("presetEditOverlay"),
    presetEditPanel: document.getElementById("presetEditPanel"),
    closePresetEditBtn: document.getElementById("closePresetEditBtn"),
    presetEditSelect: document.getElementById("presetEditSelect"),
    newPresetName: document.getElementById("newPresetName"),
    addPresetBtn: document.getElementById("addPresetBtn"),
    presetEditText: document.getElementById("presetEditText"),
    savePresetBtn: document.getElementById("savePresetBtn"),
    resetPresetBtn: document.getElementById("resetPresetBtn"),
    deletePresetBtn: document.getElementById("deletePresetBtn"),
    resetAllPresetsBtn: document.getElementById("resetAllPresetsBtn"),

    presetList: document.getElementById("presetList"),

    // notification
    notificationContainer: document.getElementById("notificationContainer"),

    // log
    logBtn: document.getElementById("logBtn"),
    logPanel: document.getElementById("logPanel"),
    logOverlay: document.getElementById("logOverlay"),
    logContent: document.getElementById("logContent"),
    closeLogBtn: document.getElementById("closeLogBtn"),
    clearLogBtn: document.getElementById("clearLogBtn"),
  });

})();
