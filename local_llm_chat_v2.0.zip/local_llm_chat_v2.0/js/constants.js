/**
 * アプリケーション定数定義
 */

(function() {
  "use strict";

  window.App = window.App || {};

  App.STORAGE_KEYS = Object.freeze({
    HISTORY: "chatHistory_v2.0",
    SETTINGS: "chatSettings_v2.0",
    PRESETS: "chatPresets_v2.0",
    DRAFT: "chatDraft_v2.0",
    PRESET_LABELS: "chatPresetLabels_v2.0",
    MODEL_VISION_CAPABILITIES: "modelVisionCapabilities_v2.0", // モデルの画像対応情報（実際の送信結果から記録）
    FILES: "chatFiles_v2.0", // アップロード済みファイル
  });

  App.LIMITS = Object.freeze({
    IMAGE_MAX_BYTES: 20 * 1024 * 1024,  // 20MB
    FILE_MAX_BYTES:  1 * 1024 * 1024,   // 1MB
    PDF_MAX_BYTES:   5 * 1024 * 1024,   // 5MB
    MAX_HISTORY_FOR_API: 12,            // system + last N-1 turns（実送信は userMessage を別途追加）
    MAX_TEXTAREA_PX: 240,
    MIN_TEXTAREA_PX: 56,
    REQUEST_TIMEOUT_MS: 30000,          // リクエストタイムアウト（30秒）
    SSE_TIMEOUT_MS: 60000,              // SSEストリームタイムアウト（60秒）
  });

  App.TIMING = Object.freeze({
    SSE_TIMEOUT_CHECK_INTERVAL_MS: 1000,  // SSEタイムアウト監視の間隔（1秒）
    NOTIFICATION_DURATION_MS: 3000,       // 通知の表示時間（3秒）
    FADE_OUT_DURATION_MS: 300,            // フェードアウトアニメーション時間（0.3秒）
    DRAFT_SAVE_DELAY_MS: 300,             // ドラフト保存の遅延時間（0.3秒）
  });

  App.DISPLAY = Object.freeze({
    MAX_ERROR_TEXT_LENGTH: 200,          // エラーテキストの最大表示長
    MAX_LOGS: 1000,                      // 最大保持ログ数
  });

  // /v1/models から取得したIDのうち、埋め込み系を除外するためのキーワード
  App.EMBEDDING_KEYWORDS = Object.freeze(["embed", "embedding", "bge", "e5-", "gte-", "jina"]);

  // 画像対応モデルを判定するためのキーワード（モデル名に含まれる場合、画像対応と判定）
  App.VISION_KEYWORDS = Object.freeze([
    "vision", "vlm", "multimodal", "gemma", "qwen2-vl", "qwen3-vl", "llava", 
    "gpt-4-vision", "claude-3", "llama-3.2-vision", "phi-3-vision",
    "ministral" // Mistral AIのMinistralシリーズは画像対応
  ]);
  
  // 画像対応モデルの完全一致パターン（モデル名が完全に一致する場合、画像対応と判定）
  // APIレスポンスにcapabilities情報がない場合のフォールバック
  App.VISION_MODEL_PATTERNS = Object.freeze([
    /^mistralai\/ministral-.*$/i,  // mistralai/ministral-* シリーズ
    /^mistral\/.*$/i,               // mistral/* シリーズ（一般的に画像対応）
    /^qwen\/qwen.*-vl.*$/i,         // qwen/qwen*-vl* シリーズ（qwen2-vl, qwen3-vlなど）
  ]);

})();
