/**
 * ファイル管理（保存、取得、削除、UI描画）
 */

(function() {
  "use strict";

  window.App = window.App || {};

  /**
   * ファイルをストレージに保存
   * @param {File} file - アップロードされたファイル
   * @returns {Promise<Object>} 保存されたファイルデータ
   */
  App.saveUploadedFile = async function(file) {
    const category = file.type.startsWith("image/") ? "image" : "document";
    
    let fileData;
    if (category === "image") {
      // 画像はDataURL形式で保存
      fileData = await App.loadImageAsDataURL(file);
    } else {
      // その他のファイルはBase64形式で保存
      fileData = await App.loadFileAsDataURL(file);
    }

    const savedFile = App.saveFile({
      name: file.name,
      type: file.type,
      category: category,
      data: fileData,
      size: file.size,
      fileObject: file.name.toLowerCase().endsWith(".pdf") ? file : null, // PDFはFileオブジェクトも保持
    });

    // UIを更新
    App.renderFileList();

    return savedFile;
  };

  /**
   * 送信キュー
   * @type {Array<string>} ファイルIDの配列
   */
  let fileQueue = [];

  /**
   * キューにファイルを追加
   * @param {string} fileId - ファイルID
   */
  App.addFileToQueue = function(fileId) {
    const file = App.getFiles().find(f => f.id === fileId);
    if (!file) return;

    // 既にキューに含まれている場合は追加しない
    if (fileQueue.includes(fileId)) {
      App.notify("⚠️ このファイルは既にキューに追加されています");
      return;
    }

    fileQueue.push(fileId);
    App.renderFileQueue();
    App.notify(`✅ 「${file.name}」をキューに追加しました`);
  };

  /**
   * キューからファイルを削除
   * @param {string} fileId - ファイルID
   */
  App.removeFileFromQueue = function(fileId) {
    const index = fileQueue.indexOf(fileId);
    if (index !== -1) {
      fileQueue.splice(index, 1);
      App.renderFileQueue();
    }
  };

  /**
   * キューをクリア
   */
  App.clearFileQueue = function() {
    fileQueue = [];
    App.renderFileQueue();
  };

  /**
   * キューに含まれるファイル一覧を取得
   * @returns {Array<Object>} ファイル配列
   */
  App.getQueuedFiles = function() {
    return fileQueue.map(id => App.getFiles().find(f => f.id === id)).filter(Boolean);
  };

  /**
   * キューにファイルが含まれているか確認
   * @param {string} fileId - ファイルID
   * @returns {boolean}
   */
  App.isFileInQueue = function(fileId) {
    return fileQueue.includes(fileId);
  };

  /**
   * ファイルを削除
   * @param {string} fileId - ファイルID
   */
  App.deleteStoredFile = function(fileId) {
    App.deleteFile(fileId);
    App.renderFileList();
    App.notify("✅ ファイルを削除しました");
  };

  /**
   * ファイルリストUIを描画
   */
  App.renderFileList = function() {
    const files = App.getFiles();
    const imageFiles = files.filter(f => f.category === "image");
    const documentFiles = files.filter(f => f.category === "document");

    // 画像リストを描画
    const imageListEl = App.el.imageFileList;
    if (imageListEl) {
      imageListEl.innerHTML = "";
      if (imageFiles.length === 0) {
        const emptyMsg = document.createElement("div");
        emptyMsg.className = "file-list-empty";
        emptyMsg.textContent = "画像がありません";
        imageListEl.appendChild(emptyMsg);
      } else {
        imageFiles.forEach(file => {
          const item = createFileItem(file);
          imageListEl.appendChild(item);
        });
      }
    }

    // その他のファイルリストを描画
    const documentListEl = App.el.documentFileList;
    if (documentListEl) {
      documentListEl.innerHTML = "";
      if (documentFiles.length === 0) {
        const emptyMsg = document.createElement("div");
        emptyMsg.className = "file-list-empty";
        emptyMsg.textContent = "ファイルがありません";
        documentListEl.appendChild(emptyMsg);
      } else {
        documentFiles.forEach(file => {
          const item = createFileItem(file);
          documentListEl.appendChild(item);
        });
      }
    }
  };

  /**
   * 送信キューUIを描画
   */
  App.renderFileQueue = function() {
    const queueListEl = App.el.fileQueueList;
    if (!queueListEl) return;

    queueListEl.innerHTML = "";

    if (fileQueue.length === 0) {
      // キューが空の場合は何も表示しない（CSSで非表示）
      // パネルを非表示
      if (App.el.fileQueuePanel) {
        App.el.fileQueuePanel.style.display = "none";
      }
    } else {
      // パネルを非表示（テキストボックス内に表示するため）
      if (App.el.fileQueuePanel) {
        App.el.fileQueuePanel.style.display = "none";
      }

      const queuedFiles = App.getQueuedFiles();
      queuedFiles.forEach((file, index) => {
        const item = createQueueItem(file);
        queueListEl.appendChild(item);
      });
    }
  };

  /**
   * キューアイテム要素を作成
   * @param {Object} file - ファイルデータ
   * @returns {HTMLElement} キューアイテム要素
   */
  function createQueueItem(file) {
    const item = document.createElement("div");
    item.className = "file-queue-item";

    // ファイル情報
    const info = document.createElement("div");
    info.className = "file-queue-info";

    if (file.category === "image") {
      const thumbnail = document.createElement("img");
      thumbnail.src = file.data;
      thumbnail.className = "file-queue-thumbnail";
      thumbnail.alt = file.name;
      info.appendChild(thumbnail);
    } else {
      const icon = document.createElement("div");
      icon.className = "file-queue-icon";
      icon.textContent = "📄";
      info.appendChild(icon);
    }

    const name = document.createElement("div");
    name.className = "file-queue-name";
    name.textContent = file.name;
    info.appendChild(name);

    // 削除ボタン
    const removeBtn = document.createElement("button");
    removeBtn.className = "file-queue-remove-btn";
    removeBtn.textContent = "×";
    removeBtn.title = "キューから削除";
    removeBtn.onclick = (e) => {
      e.stopPropagation();
      App.removeFileFromQueue(file.id);
      App.notify(`✅ 「${file.name}」をキューから削除しました`);
    };

    item.appendChild(info);
    item.appendChild(removeBtn);

    return item;
  }

  /**
   * ファイルアイテム要素を作成
   * @param {Object} file - ファイルデータ
   * @returns {HTMLElement} ファイルアイテム要素
   */
  function createFileItem(file) {
    const item = document.createElement("div");
    item.className = "file-item";
    
    // キューに含まれている場合はハイライト
    const isInQueue = App.isFileInQueue(file.id);
    if (isInQueue) {
      item.classList.add("queued");
    }

    // チェックボックス
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = isInQueue;
    checkbox.className = "file-checkbox";
    checkbox.onchange = (e) => {
      e.stopPropagation();
      if (checkbox.checked) {
        App.addFileToQueue(file.id);
      } else {
        App.removeFileFromQueue(file.id);
      }
      // ファイルリストを再描画してキュー状態を反映
      App.renderFileList();
    };

    // ファイルアイテム全体のクリックでチェックボックスをトグル
    item.onclick = (e) => {
      // 削除ボタンやチェックボックス自体のクリック時は処理しない
      if (e.target.classList.contains("file-delete-btn") || e.target === checkbox) {
        return;
      }
      // チェックボックスの状態をトグル
      checkbox.checked = !checkbox.checked;
      if (checkbox.checked) {
        App.addFileToQueue(file.id);
      } else {
        App.removeFileFromQueue(file.id);
      }
      // ファイルリストを再描画してキュー状態を反映
      App.renderFileList();
    };

    // ファイル情報コンテナ
    const info = document.createElement("div");
    info.className = "file-info";

    if (file.category === "image") {
      // 画像の場合はサムネイルを表示
      const thumbnail = document.createElement("img");
      thumbnail.src = file.data;
      thumbnail.className = "file-thumbnail";
      thumbnail.alt = file.name;
      info.appendChild(thumbnail);
    } else {
      // その他のファイルはアイコンを表示
      const icon = document.createElement("div");
      icon.className = "file-icon";
      icon.textContent = "📄";
      info.appendChild(icon);
    }

    // ファイル名とサイズ
    const details = document.createElement("div");
    details.className = "file-details";
    const name = document.createElement("div");
    name.className = "file-name";
    name.textContent = file.name;
    const size = document.createElement("div");
    size.className = "file-size";
    size.textContent = formatFileSize(file.size);
    details.appendChild(name);
    details.appendChild(size);
    info.appendChild(details);

    // 削除ボタン
    const deleteBtn = document.createElement("button");
    deleteBtn.className = "file-delete-btn";
    deleteBtn.textContent = "🗑";
    deleteBtn.title = "削除";
    deleteBtn.onclick = (e) => {
      e.stopPropagation();
      if (confirm(`「${file.name}」を削除しますか？`)) {
        // キューにも含まれている場合はキューからも削除
        if (App.isFileInQueue(file.id)) {
          App.removeFileFromQueue(file.id);
        }
        App.deleteStoredFile(file.id);
      }
    };

    item.appendChild(checkbox);
    item.appendChild(info);
    item.appendChild(deleteBtn);

    return item;
  }

  /**
   * ファイルサイズをフォーマット
   * @param {number} bytes - バイト数
   * @returns {string} フォーマットされたサイズ文字列
   */
  function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  }

})();

