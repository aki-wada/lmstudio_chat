/**
 * アプリケーションエントリーポイント
 */

(function() {
  "use strict";

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------

  /** @type {{controller: AbortController|null, availableModels:Set<string>, modelVisionCapableMap:Map<string,boolean>, allModelData:Array}} */
  const runtime = {
    abortController: null,          // Stopボタン用
    availableModels: new Set(),     // /v1/models の正確なID一覧
    modelVisionCapableMap: new Map(), // モデルID -> 画像対応フラグ
    allModelData: []                 // /v1/models のレスポンスのdata配列（capabilities情報を含む）
  };


  /**
   * 入力欄の「最後の1文字が残る」系のブラウザ挙動を避けるための強いクリア
   */
  function strongClearPrompt() {
    App.el.prompt.value = "";
    App.clearDraft();
    App.el.prompt.dispatchEvent(new Event("input", { bubbles: true }));
    App.el.prompt.setSelectionRange(0, 0);
    App.el.prompt.blur();
    setTimeout(() => { App.el.prompt.value = ""; }, 0);
    setTimeout(() => { App.el.prompt.focus(); }, 10);
  }

  // ---------------------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------------------

  function renderHistoryFromStorage() {
    const messages = App.loadHistory();
    messages.forEach(m => App.appendMessage(m.role, m.content, { save: false }));
  }

  async function init() {
    App.setupMarkdown();

    const settings = App.loadSettings();
    App.setSettings(settings);
    App.applySettingsToUI();

    const draft = App.loadDraft();
    if (draft) {
      App.el.prompt.value = draft;
      App.autoResizeTextarea(App.el.prompt);
    }

    App.loadCustomPresets();
    App.loadCustomPresetLabels();
    App.renderPresetUI();
    App.loadPresetToEditor();

    renderHistoryFromStorage();

    // ファイル管理の初期化
    App.loadFiles();
    App.renderFileList();
    App.renderFileQueue();
    App.wireFileListEvents();

    // ログ機能の初期化
    App.wireLogEvents();

    App.wireSettingsEvents(App.notify);
    App.el.settingsBtn.onclick = App.toggleSettingsPanel;
    App.el.closeSettingsBtn.onclick = App.closeSettingsPanel;
    if (App.el.resetSettingsBtn) {
      App.el.resetSettingsBtn.onclick = App.resetSettingsToDefault;
    }
    if (App.el.clearAllDataBtn) {
      App.el.clearAllDataBtn.onclick = App.clearAllData;
    }
    App.el.fileListBtn.onclick = App.toggleFileListPanel;

    App.el.sendBtn.onclick = () => App.handleSend(runtime, runtime.availableModels, runtime.modelVisionCapableMap, runtime.allModelData, strongClearPrompt);
    App.el.stopBtn.onclick = () => App.handleStop(runtime);
    App.el.refreshBtn.onclick = () => App.refreshModels(runtime.availableModels, runtime.modelVisionCapableMap, runtime.allModelData);
    App.el.exportBtn.onclick = App.exportHistory;
    App.el.clearBtn.onclick = App.clearHistory;

    App.wireTextareaResize();
    App.wireAttachmentEvents(App.handleFileUpload);
    App.wirePresetEvents(
      App.loadPresetToEditor,
      App.savePresetFromEditor,
      App.resetPresetToDefault,
      App.deleteSelectedPreset,
      App.resetAllPresets,
      App.addNewPreset,
      App.togglePresetPanel,
      App.closePresetPanel,
      App.togglePresetEditPanel,
      App.closePresetEditPanel
    );
    App.setupKeyboardShortcuts(
      () => App.handleSend(runtime, runtime.availableModels, runtime.modelVisionCapableMap, runtime.allModelData, strongClearPrompt),
      App.clearHistory
    );
    App.setupPasteImage();
    App.setupDragAndDropImage();

    // 起動時に同期
    await App.refreshModels(runtime.availableModels, runtime.modelVisionCapableMap, runtime.allModelData);
  }

  // bootstrap
  init();

})();
