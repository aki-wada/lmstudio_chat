# Changelog

All notable changes to Local LLM Chat will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0] - 2025-12-21

### Added
- **ログ機能** - デバッグ、情報、警告、エラーの4つのログレベルを提供するログパネルを追加
  - ログパネルでログを確認可能
  - ログのクリア機能
  - 最大1000件のログを保持
- **ファイル添付機能の拡張** - すでにクライアントにアップロードしたファイルを送信キューに追加して再利用可能に
  - ファイルリストパネルでアップロード済みファイルを管理
  - チェックボックスで送信キューに追加/削除
  - 画像とドキュメントを分類して表示
- **設定リセットボタン** - 設定パネルに「🔄 設定をデフォルトに戻す」ボタンを追加

### Changed
- **ファイル添付機能の修正** - ファイル添付機能が正しく動作するように修正
- **プリセット設定の分離** - 設定画面からプリセット設定を分離し、独立したプリセット編集パネルに移動
  - プリセットパネルから「⚙️ プリセット設定」ボタンで編集パネルを開く
  - 設定パネルとプリセット編集パネルを独立して管理
- **UIの一新** - ユーザーインターフェースを全面的に刷新
  - モダンなデザインに更新
  - パネルレイアウトの改善
  - ファイル管理UIの追加
  - ログパネルの追加
- **バージョン表記の更新** - v1.5からv2.0に更新

### Technical Details
- HTML + 外部アセット構成（変更なし）
- データ保存: localStorage（キー: `chatHistory_v2.0`, `chatSettings_v2.0`, `chatPresets_v2.0`, `chatFiles_v2.0` など）

---

## [1.4] - 2025-12-18

### Changed
- **コードリファクタリング** - 保守性・可読性の大幅向上
  - IIFE（即時実行関数式）でグローバルスコープ汚染を防止
  - JSDoc による型定義の追加（StoredMessage, Settings 等）
  - 定数の一元管理（STORAGE_KEYS, LIMITS, EMBEDDING_KEYWORDS）
  - DOM参照を `el` オブジェクトに集約（Single Source of Truth）
  - 状態管理を `runtime`, `attach` オブジェクトに分離
  - 機能ごとにセクション分割（Settings, Chat UI, SSE, Presets 等）
  - SSE処理を `consumeSSE()` 関数に抽出
  - イベント配線を `wireSettingsEvents()` 等に分離
  - `Object.freeze()` による定数の不変性保証

### Technical Details
- HTML + 外部アセット構成（変更なし）
- データ保存: localStorage（キー: `chatHistory_v1.4`, `chatSettings_v1.4`, `chatPresets_v1.4`）

---

## [1.3] - 2025-12-17

### Added
- **プリセットプロンプト機能** - 📋 Preset ボタンで構造化テンプレートを挿入（6種類）
  - 🏥 疾患解説、💊 鑑別診断、📄 文章要約
  - 📝 論文査読、🔬 リサーチデザイン、📈 統計解析
- **プリセット編集機能** - Settings パネルでプリセット内容をカスタマイズ可能
- **完全オフライン対応** - 外部ライブラリをローカルに同梱
  - `assets/app.css` - スタイルシート
  - `assets/marked.min.js` - Markdown レンダリング
  - `assets/pdf.min.js` - PDF テキスト抽出
  - `assets/pdf.worker.min.js` - PDF.js Worker

### Changed
- ファイル名を `local_llm_chat_v1.3.html` に変更
- CDN依存を完全に排除（閉域ネットワーク対応）
- スタイルシートを外部ファイル化（app.css）

### Technical Details
- HTML + 外部アセット構成
- 外部依存: marked.js, PDF.js（すべてローカル同梱）
- データ保存: localStorage（キー: `chatHistory_v1.3`, `chatSettings_v1.3`）

---

## [1.1.0] - 2025-11-29

### Added
- ファイル添付機能を追加（📎 File ボタン）
  - 対応形式: .txt, .md, .json, .csv, .xml, .html, .css, .js, .ts, .py, .java, .c, .cpp, .h, .hpp, .sh, .yaml, .yml, .log, .pdf
  - テキストファイルは内容をメッセージに含めて送信
  - PDFファイルのテキスト抽出に対応（PDF.jsを使用）
    - PDFからテキストを抽出してメッセージに含める
    - 抽出に失敗した場合はファイル名のみを送信
- 画像のドラッグ＆ドロップに対応
  - ウィンドウ内に画像をドロップして添付可能
  - ドラッグ中は画面が薄くなり、ドロップ可能であることを視覚的に表示
- Settings パネルに「← 戻る」ボタンを追加
- 埋め込みモデル（text embedding model）の自動フィルタリング
  - チャットに使用できない埋め込みモデルをモデル一覧から自動除外
  - 除外キーワード: embed, embedding, bge, e5-, gte-, jina
- Settings の各項目に説明文を追加
  - Temperature: 「※ 低いと安定、高いと創造的」
  - Base URL: デフォルト値を付記

### Changed
- アプリ名を「LM Studio Chat」から「Local LLM Chat」に変更
- ファイル名を `lmstudio_chat_auto_models.html` から `local_llm_chat.html` に変更
- OpenAI 互換 API をサポートするすべてのローカル LLM サーバーに対応
- ヘッダーレイアウトを2段構成に変更
  - 1段目: タイトル + モデル選択 + Refresh
  - 2段目: Clear + Export + Settings
- 入力エリアのレイアウトを変更
  - 左側: 📷 Image + 📎 File
  - 中央: テキスト入力
  - 右側: 送信 + ⏹ Stop
- Base URL、API Key を Settings パネル内に移動（UI簡略化）

### Fixed
- ストリーミング応答のコピー機能が正しく動作しない問題を修正
  - `dataset.content` を使用してコピーするように変更
  - ストリーミング完了時に `dataset.content` を更新するように修正

---

## [1.0.0] - 2025-11-23

### Added

#### ユーザープロフィール機能
- 専門レベルの設定（指定なし/初心者/中級者/上級者/専門家）
- 職業/専門分野の入力
- 興味・関心の入力
- プロフィール情報に基づいた応答の最適化
- プロフィール情報の自動保存（localStorage）

#### 応答スタイルカスタマイズ
- 4つの応答スタイル（簡潔/標準/詳細/専門的）
- システムプロンプトへの自動統合
- 応答スタイルの記憶機能

#### 基本機能
- LM Studio との自動モデル同期
- ストリーミング応答（Server-Sent Events）
- Vision API 対応（画像入力・ペースト）
- マルチモーダルメッセージ送信
- ダークモード
- メッセージ管理（コピー、削除、再生成）
- 会話履歴の永続化（localStorage）
- 会話履歴の JSON エクスポート

#### UI/UX
- レスポンシブデザイン
- 入力欄の自動拡張
- キーボードショートカット
  - `Enter`: メッセージ送信
  - `Shift + Enter`: 改行
  - `Ctrl/Cmd + V`: 画像ペースト
  - `Ctrl/Cmd + K`: 履歴クリア
  - `Esc`: 設定パネルを閉じる

#### 設定機能
- Temperature 調整（0.0-2.0）
- Max Tokens 設定（1-8192）
- System Prompt カスタマイズ
- Base URL / API Key 設定
- すべての設定の自動保存

### Fixed
- 日本語 IME 変換中の誤送信防止
- 入力欄の強制クリア処理
- モデル選択の状態管理

### Technical Details
- 単一 HTML ファイル構成（約 700 行）
- 外部依存: marked.js（CDN 経由）
- データ保存: localStorage
- API: OpenAI 互換 API（LM Studio）

---

## [Unreleased]

### 計画中の機能
- 会話履歴の JSON インポート機能
- カスタムテーマのサポート
- 会話のフォルダ分類
- メッセージの検索機能
- 音声入力対応

---

## リリースノート形式

各バージョンは以下のカテゴリで分類されます：

- `Added`: 新機能
- `Changed`: 既存機能の変更
- `Deprecated`: 非推奨となった機能
- `Removed`: 削除された機能
- `Fixed`: バグ修正
- `Security`: セキュリティ関連の修正

---

**バージョン履歴**

- [2.0] - 2025-01-XX - ファイル添付機能の修正・拡張、ログ機能追加、プリセット設定の分離、UI一新
- [1.4] - 2025-12-18 - コードリファクタリング、保守性向上
- [1.3] - 2025-12-17 - プリセットプロンプト機能、完全オフライン対応
- [1.1.0] - 2025-11-29 - アプリ名変更、ファイル添付、ドラッグ＆ドロップ対応、UI改善
- [1.0.0] - 2025-11-23 - 初回リリース
